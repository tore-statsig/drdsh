
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ../../private-js-client-monorepo/packages/client-core/src/Log.ts
function addTag(args) {
  args.unshift("[Statsig]");
  return args;
}
var DEBUG, _INFO, _WARN, ERROR, LogLevel, Log;
var init_Log = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/Log.ts"() {
    "use strict";
    DEBUG = " DEBUG ";
    _INFO = "  INFO ";
    _WARN = "  WARN ";
    ERROR = " ERROR ";
    LogLevel = {
      None: 0,
      Error: 1,
      Warn: 2,
      Info: 3,
      Debug: 4
    };
    Log = class _Log {
      static {
        this.level = LogLevel.Warn;
      }
      static info(...args) {
        if (_Log.level >= LogLevel.Info) {
          console.info(_INFO, ...addTag(args));
        }
      }
      static debug(...args) {
        if (_Log.level >= LogLevel.Debug) {
          console.debug(DEBUG, ...addTag(args));
        }
      }
      static warn(...args) {
        if (_Log.level >= LogLevel.Warn) {
          console.warn(_WARN, ...addTag(args));
        }
      }
      static error(...args) {
        if (_Log.level >= LogLevel.Error) {
          console.error(ERROR, ...addTag(args));
        }
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/$_StatsigGlobal.ts
var _getStatsigGlobal, _getStatsigGlobalFlag, _getInstance, GLOBAL_KEY, _window, _global, _globalThis, statsigGlobal;
var init_StatsigGlobal = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/$_StatsigGlobal.ts"() {
    "use strict";
    init_Log();
    _getStatsigGlobal = () => {
      try {
        return typeof __STATSIG__ !== "undefined" ? __STATSIG__ : statsigGlobal;
      } catch (e) {
        return statsigGlobal;
      }
    };
    _getStatsigGlobalFlag = (flag) => {
      return _getStatsigGlobal()[flag];
    };
    _getInstance = (sdkKey) => {
      const gbl = _getStatsigGlobal();
      if (!sdkKey) {
        if (gbl.instances && Object.keys(gbl.instances).length > 1) {
          Log.warn(
            "Call made to Statsig global instance without an SDK key but there is more than one client instance. If you are using mulitple clients, please specify the SDK key."
          );
        }
        return gbl.firstInstance;
      }
      return gbl.instances && gbl.instances[sdkKey];
    };
    GLOBAL_KEY = "__STATSIG__";
    _window = typeof window !== "undefined" ? window : {};
    _global = typeof global !== "undefined" ? global : {};
    _globalThis = typeof globalThis !== "undefined" ? globalThis : {};
    statsigGlobal = _window[GLOBAL_KEY] ?? _global[GLOBAL_KEY] ?? _globalThis[GLOBAL_KEY] ?? {
      instance: _getInstance
    };
    _window[GLOBAL_KEY] = statsigGlobal;
    _global[GLOBAL_KEY] = statsigGlobal;
    _globalThis[GLOBAL_KEY] = statsigGlobal;
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/Diagnostics.ts
function _createMarker(data, action, key, step) {
  return {
    key,
    action,
    step,
    timestamp: Date.now(),
    ...data
  };
}
function _makeDiagnosticsEvent(user, data) {
  const latencyEvent = {
    eventName: DIAGNOSTICS_EVENT,
    user,
    value: null,
    metadata: data,
    time: Date.now()
  };
  return latencyEvent;
}
function _addMarker(sdkKey, marker) {
  const markers = MARKER_MAP.get(sdkKey) ?? [];
  markers.push(marker);
  MARKER_MAP.set(sdkKey, markers);
}
function _safeGetField(data, field) {
  if (field in data) {
    return data[field];
  }
  return void 0;
}
var MARKER_MAP, ACT_START, ACT_END, DIAGNOSTICS_EVENT, Diagnostics;
var init_Diagnostics = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/Diagnostics.ts"() {
    "use strict";
    MARKER_MAP = /* @__PURE__ */ new Map();
    ACT_START = "start";
    ACT_END = "end";
    DIAGNOSTICS_EVENT = "statsig::diagnostics";
    Diagnostics = {
      _getMarkers: (sdkKey) => {
        return MARKER_MAP.get(sdkKey);
      },
      _markInitOverallStart: (sdkKey) => {
        _addMarker(sdkKey, _createMarker({}, ACT_START, "overall"));
      },
      _markInitOverallEnd: (sdkKey, success, evaluationDetails) => {
        _addMarker(
          sdkKey,
          _createMarker(
            {
              success,
              error: success ? void 0 : { name: "InitializeError", message: "Failed to initialize" },
              evaluationDetails
            },
            ACT_END,
            "overall"
          )
        );
      },
      _markInitNetworkReqStart: (sdkKey, data) => {
        _addMarker(
          sdkKey,
          _createMarker(data, ACT_START, "initialize", "network_request")
        );
      },
      _markInitNetworkReqEnd: (sdkKey, data) => {
        _addMarker(
          sdkKey,
          _createMarker(data, ACT_END, "initialize", "network_request")
        );
      },
      _markInitProcessStart: (sdkKey) => {
        _addMarker(sdkKey, _createMarker({}, ACT_START, "initialize", "process"));
      },
      _markInitProcessEnd: (sdkKey, data) => {
        _addMarker(sdkKey, _createMarker(data, ACT_END, "initialize", "process"));
      },
      _clearMarkers: (sdkKey) => {
        MARKER_MAP.delete(sdkKey);
      },
      _formatError(e) {
        if (!(e && typeof e === "object")) {
          return;
        }
        return {
          code: _safeGetField(e, "code"),
          name: _safeGetField(e, "name"),
          message: _safeGetField(e, "message")
        };
      },
      _getDiagnosticsData(res, attempt, body, e) {
        return {
          success: res?.ok === true,
          statusCode: res?.status,
          sdkRegion: res?.headers?.get("x-statsig-region"),
          isDelta: body.includes('"is_delta":true') === true ? true : void 0,
          attempt,
          error: Diagnostics._formatError(e)
        };
      },
      _enqueueDiagnosticsEvent(user, logger, sdk, options) {
        const markers = Diagnostics._getMarkers(sdk);
        if (markers == null || markers.length <= 0) {
          return -1;
        }
        const overallInitDuration = markers[markers.length - 1].timestamp - markers[0].timestamp;
        Diagnostics._clearMarkers(sdk);
        const event = _makeDiagnosticsEvent(user, {
          context: "initialize",
          markers: markers.slice(),
          statsigOptions: options
        });
        logger.enqueue(event);
        return overallInitDuration;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/TypingUtils.ts
function _typeOf(input) {
  return Array.isArray(input) ? "array" : typeof input;
}
function _isTypeMatch(a, b) {
  const typeOf = (x) => Array.isArray(x) ? "array" : x === null ? "null" : typeof x;
  return typeOf(a) === typeOf(b);
}
var init_TypingUtils = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/TypingUtils.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/Hashing.ts
var _DJB2, _DJB2Object, _getSortedObject;
var init_Hashing = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/Hashing.ts"() {
    "use strict";
    init_TypingUtils();
    _DJB2 = (value) => {
      let hash = 0;
      for (let i = 0; i < value.length; i++) {
        const character = value.charCodeAt(i);
        hash = (hash << 5) - hash + character;
        hash = hash & hash;
      }
      return String(hash >>> 0);
    };
    _DJB2Object = (value, maxLevels) => {
      return _DJB2(JSON.stringify(_getSortedObject(value, maxLevels)));
    };
    _getSortedObject = (object, maxDepth) => {
      if (object == null) {
        return null;
      }
      const keys = Object.keys(object).sort();
      const sortedObject = {};
      keys.forEach((key) => {
        const value = object[key];
        if (maxDepth === 0 || _typeOf(value) !== "object") {
          sortedObject[key] = value;
          return;
        }
        sortedObject[key] = _getSortedObject(
          value,
          maxDepth != null ? maxDepth - 1 : maxDepth
        );
      });
      return sortedObject;
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/CacheKey.ts
function _getUserStorageKey(sdkKey, user, customKeyGenerator) {
  if (customKeyGenerator) {
    return customKeyGenerator(sdkKey, user);
  }
  const cids = user && user.customIDs ? user.customIDs : {};
  const parts = [
    `uid:${user?.userID ?? ""}`,
    `cids:${Object.keys(cids).sort((leftKey, rightKey) => leftKey.localeCompare(rightKey)).map((key) => `${key}-${cids[key]}`).join(",")}`,
    `k:${sdkKey}`
  ];
  return _DJB2(parts.join("|"));
}
function _getStorageKey(sdkKey, user, customKeyGenerator) {
  if (user) {
    return _getUserStorageKey(sdkKey, user, customKeyGenerator);
  }
  return _DJB2(`k:${sdkKey}`);
}
var init_CacheKey = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/CacheKey.ts"() {
    "use strict";
    init_Hashing();
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/NetworkConfig.ts
var Endpoint, NetworkDefault, NetworkParam;
var init_NetworkConfig = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/NetworkConfig.ts"() {
    "use strict";
    Endpoint = {
      _initialize: "initialize",
      _rgstr: "rgstr",
      _download_config_specs: "download_config_specs"
    };
    NetworkDefault = {
      [Endpoint._rgstr]: "https://prodregistryv2.org/v1",
      [Endpoint._initialize]: "https://featureassets.org/v1",
      [Endpoint._download_config_specs]: "https://api.statsigcdn.com/v1"
    };
    NetworkParam = {
      EventCount: "ec",
      SdkKey: "k",
      SdkType: "st",
      SdkVersion: "sv",
      Time: "t",
      SessionID: "sid",
      StatsigEncoded: "se",
      IsGzipped: "gz"
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/SafeJs.ts
var _getWindowSafe, _getDocumentSafe, _isServerEnv, _addWindowEventListenerSafe, _addDocumentEventListenerSafe, _getCurrentPageUrlSafe, _getUnloadEvent;
var init_SafeJs = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/SafeJs.ts"() {
    "use strict";
    _getWindowSafe = () => {
      return typeof window !== "undefined" ? window : null;
    };
    _getDocumentSafe = () => {
      const win = _getWindowSafe();
      return win?.document ?? null;
    };
    _isServerEnv = () => {
      if (_getDocumentSafe() !== null) {
        return false;
      }
      const isNode = typeof process !== "undefined" && process.versions != null && process.versions.node != null;
      const isVercel = typeof EdgeRuntime === "string";
      return isVercel || isNode;
    };
    _addWindowEventListenerSafe = (key, listener) => {
      const win = _getWindowSafe();
      if (typeof win?.addEventListener === "function") {
        win.addEventListener(key, listener);
      }
    };
    _addDocumentEventListenerSafe = (key, listener) => {
      const doc = _getDocumentSafe();
      if (typeof doc?.addEventListener === "function") {
        doc.addEventListener(key, listener);
      }
    };
    _getCurrentPageUrlSafe = () => {
      try {
        return _getWindowSafe()?.location.href.split(/[?#]/)[0];
      } catch {
        return;
      }
    };
    _getUnloadEvent = () => {
      const win = _getWindowSafe();
      if (!win) {
        return "beforeunload";
      }
      const eventType = "onpagehide" in win ? "pagehide" : "beforeunload";
      return eventType;
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigEvent.ts
function _mapExposures(exposures, exposureMapping) {
  return exposures.map((exposure) => {
    if (typeof exposure === "string") {
      return (exposureMapping ?? {})[exposure];
    }
    return exposure;
  }).filter((exposure) => exposure != null);
}
var CONFIG_EXPOSURE_NAME, GATE_EXPOSURE_NAME, LAYER_EXPOSURE_NAME, _createExposure, _isExposureEvent, _createGateExposure, _createConfigExposure, _createLayerParameterExposure, _addEvaluationDetailsToMetadata;
var init_StatsigEvent = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigEvent.ts"() {
    "use strict";
    CONFIG_EXPOSURE_NAME = "statsig::config_exposure";
    GATE_EXPOSURE_NAME = "statsig::gate_exposure";
    LAYER_EXPOSURE_NAME = "statsig::layer_exposure";
    _createExposure = (eventName, user, details, metadata2, secondaryExposures) => {
      if (details.bootstrapMetadata) {
        metadata2["bootstrapMetadata"] = details.bootstrapMetadata;
      }
      return {
        eventName,
        user,
        value: null,
        metadata: _addEvaluationDetailsToMetadata(details, metadata2),
        secondaryExposures,
        time: Date.now()
      };
    };
    _isExposureEvent = ({
      eventName
    }) => {
      return eventName === GATE_EXPOSURE_NAME || eventName === CONFIG_EXPOSURE_NAME || eventName === LAYER_EXPOSURE_NAME;
    };
    _createGateExposure = (user, gate, exposureMapping) => {
      const metadata2 = {
        gate: gate.name,
        gateValue: String(gate.value),
        ruleID: gate.ruleID
      };
      if (gate.__evaluation?.version != null) {
        metadata2["configVersion"] = gate.__evaluation.version;
      }
      return _createExposure(
        GATE_EXPOSURE_NAME,
        user,
        gate.details,
        metadata2,
        _mapExposures(
          gate.__evaluation?.secondary_exposures ?? [],
          exposureMapping
        )
      );
    };
    _createConfigExposure = (user, config2, exposureMapping) => {
      const metadata2 = {
        config: config2.name,
        ruleID: config2.ruleID
      };
      if (config2.__evaluation?.version != null) {
        metadata2["configVersion"] = config2.__evaluation.version;
      }
      if (config2.__evaluation?.passed != null) {
        metadata2["rulePassed"] = String(config2.__evaluation.passed);
      }
      return _createExposure(
        CONFIG_EXPOSURE_NAME,
        user,
        config2.details,
        metadata2,
        _mapExposures(
          config2.__evaluation?.secondary_exposures ?? [],
          exposureMapping
        )
      );
    };
    _createLayerParameterExposure = (user, layer, parameterName, exposureMapping) => {
      const evaluation = layer.__evaluation;
      const isExplicit = evaluation?.explicit_parameters?.includes(parameterName) === true;
      let allocatedExperiment = "";
      let secondaryExposures = evaluation?.undelegated_secondary_exposures ?? [];
      if (isExplicit) {
        allocatedExperiment = evaluation.allocated_experiment_name ?? "";
        secondaryExposures = evaluation.secondary_exposures ?? [];
      }
      const parameterRuleIDs = layer.__evaluation?.parameter_rule_ids;
      const metadata2 = {
        config: layer.name,
        parameterName,
        ruleID: parameterRuleIDs?.[parameterName] ?? layer.ruleID,
        allocatedExperiment,
        isExplicitParameter: String(isExplicit)
      };
      if (layer.__evaluation?.version != null) {
        metadata2["configVersion"] = layer.__evaluation.version;
      }
      return _createExposure(
        LAYER_EXPOSURE_NAME,
        user,
        layer.details,
        metadata2,
        _mapExposures(secondaryExposures, exposureMapping)
      );
    };
    _addEvaluationDetailsToMetadata = (details, metadata2) => {
      metadata2["reason"] = details.reason;
      if (details.lcut) {
        metadata2["lcut"] = String(details.lcut);
      }
      if (details.receivedAt) {
        metadata2["receivedAt"] = String(details.receivedAt);
      }
      return metadata2;
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigOptionsCommon.ts
var LogEventCompressionMode, LoggingEnabledOption;
var init_StatsigOptionsCommon = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigOptionsCommon.ts"() {
    "use strict";
    LogEventCompressionMode = {
      /** Do not compress request bodies */
      Disabled: "d",
      /** Compress request bodies unless a network proxy is configured */
      Enabled: "e",
      /** Always compress request bodies, even when a proxy is configured */
      Forced: "f"
    };
    LoggingEnabledOption = {
      disabled: "disabled",
      browserOnly: "browser-only",
      always: "always"
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StorageProvider.ts
function _inMemoryBreaker(action) {
  try {
    return action();
  } catch (error) {
    if (error instanceof Error && error.name === "SecurityError") {
      Storage._setProvider(_inMemoryProvider);
      return null;
    }
    if (error instanceof Error && error.name === "QuotaExceededError") {
      const allKeys = Storage.getAllKeys();
      const statsigKeys = allKeys.filter((key) => key.startsWith("statsig."));
      error.message = `${error.message}. Statsig Keys: ${statsigKeys.length}`;
    }
    throw error;
  }
}
function _getObjectFromStorage(key) {
  const value = Storage.getItem(key);
  return JSON.parse(value ?? "null");
}
function _setObjectInStorage(key, obj) {
  Storage.setItem(key, JSON.stringify(obj));
}
var inMemoryStore, _inMemoryProvider, _localStorageProvider, _main, _current, Storage;
var init_StorageProvider = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StorageProvider.ts"() {
    "use strict";
    init_Log();
    init_SafeJs();
    inMemoryStore = {};
    _inMemoryProvider = {
      isReady: () => true,
      isReadyResolver: () => null,
      getProviderName: () => "InMemory",
      getItem: (key) => inMemoryStore[key] ? inMemoryStore[key] : null,
      setItem: (key, value) => {
        inMemoryStore[key] = value;
      },
      removeItem: (key) => {
        delete inMemoryStore[key];
      },
      getAllKeys: () => Object.keys(inMemoryStore)
    };
    _localStorageProvider = null;
    try {
      const win = _getWindowSafe();
      if (win && win.localStorage && typeof win.localStorage.getItem === "function") {
        _localStorageProvider = {
          isReady: () => true,
          isReadyResolver: () => null,
          getProviderName: () => "LocalStorage",
          getItem: (key) => win.localStorage.getItem(key),
          setItem: (key, value) => win.localStorage.setItem(key, value),
          removeItem: (key) => win.localStorage.removeItem(key),
          getAllKeys: () => Object.keys(win.localStorage)
        };
      }
    } catch (error) {
      Log.warn("Failed to setup localStorageProvider.");
    }
    _main = _localStorageProvider ?? _inMemoryProvider;
    _current = _main;
    Storage = {
      isReady: () => _current.isReady(),
      isReadyResolver: () => _current.isReadyResolver(),
      getProviderName: () => _current.getProviderName(),
      getItem: (key) => _inMemoryBreaker(() => _current.getItem(key)),
      setItem: (key, value) => _inMemoryBreaker(() => _current.setItem(key, value)),
      removeItem: (key) => _current.removeItem(key),
      getAllKeys: () => _current.getAllKeys(),
      // StorageProviderManagment
      _setProvider: (newProvider) => {
        _main = newProvider;
        _current = newProvider;
      },
      _setDisabled: (isDisabled) => {
        if (isDisabled) {
          _current = _inMemoryProvider;
        } else {
          _current = _main;
        }
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/UrlConfiguration.ts
var ENDPOINT_DNS_KEY_MAP, UrlConfiguration;
var init_UrlConfiguration = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/UrlConfiguration.ts"() {
    "use strict";
    init_Hashing();
    init_NetworkConfig();
    ENDPOINT_DNS_KEY_MAP = {
      [Endpoint._initialize]: "i",
      [Endpoint._rgstr]: "e",
      [Endpoint._download_config_specs]: "d"
    };
    UrlConfiguration = class {
      constructor(endpoint, customUrl, customApi, fallbackUrls) {
        this.customUrl = null;
        this.fallbackUrls = null;
        this.endpoint = endpoint;
        this.endpointDnsKey = ENDPOINT_DNS_KEY_MAP[endpoint];
        if (customUrl) {
          this.customUrl = customUrl;
        }
        if (!customUrl && customApi) {
          this.customUrl = customApi.endsWith("/") ? `${customApi}${endpoint}` : `${customApi}/${endpoint}`;
        }
        if (fallbackUrls) {
          this.fallbackUrls = fallbackUrls;
        }
        const defaultApi = NetworkDefault[endpoint];
        this.defaultUrl = `${defaultApi}/${endpoint}`;
      }
      getUrl() {
        return this.customUrl ?? this.defaultUrl;
      }
      getChecksum() {
        const fallbacks = (this.fallbackUrls ?? []).sort().join(",");
        return _DJB2(this.customUrl + fallbacks);
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/VisibilityObserving.ts
var FOREGROUND, BACKGROUND, LISTENERS, current, isUnloading, _isCurrentlyVisible, _isUnloading, _subscribeToVisiblityChanged, _notifyVisibilityChanged;
var init_VisibilityObserving = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/VisibilityObserving.ts"() {
    "use strict";
    init_SafeJs();
    FOREGROUND = "foreground";
    BACKGROUND = "background";
    LISTENERS = [];
    current = FOREGROUND;
    isUnloading = false;
    _isCurrentlyVisible = () => {
      return current === FOREGROUND;
    };
    _isUnloading = () => isUnloading;
    _subscribeToVisiblityChanged = (listener) => {
      LISTENERS.unshift(listener);
    };
    _notifyVisibilityChanged = (visibility) => {
      if (visibility === current) {
        return;
      }
      current = visibility;
      LISTENERS.forEach((l) => l(visibility));
    };
    _addWindowEventListenerSafe("focus", () => {
      isUnloading = false;
      _notifyVisibilityChanged(FOREGROUND);
    });
    _addWindowEventListenerSafe("blur", () => _notifyVisibilityChanged(BACKGROUND));
    _addDocumentEventListenerSafe("visibilitychange", () => {
      _notifyVisibilityChanged(
        document.visibilityState === "visible" ? FOREGROUND : BACKGROUND
      );
    });
    _addWindowEventListenerSafe(_getUnloadEvent(), () => {
      isUnloading = true;
      _notifyVisibilityChanged(BACKGROUND);
    });
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/EventLogger.ts
var DEFAULT_QUEUE_SIZE, DEFAULT_FLUSH_INTERVAL_MS, MAX_DEDUPER_KEYS, DEDUPER_WINDOW_DURATION_MS, MAX_FAILED_LOGS, QUICK_FLUSH_WINDOW_MS, EVENT_LOGGER_MAP, RetryFailedLogsTrigger, EventLogger;
var init_EventLogger = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/EventLogger.ts"() {
    "use strict";
    init_CacheKey();
    init_Hashing();
    init_Log();
    init_NetworkConfig();
    init_SafeJs();
    init_StatsigEvent();
    init_StatsigOptionsCommon();
    init_StorageProvider();
    init_UrlConfiguration();
    init_VisibilityObserving();
    DEFAULT_QUEUE_SIZE = 100;
    DEFAULT_FLUSH_INTERVAL_MS = 1e4;
    MAX_DEDUPER_KEYS = 1e3;
    DEDUPER_WINDOW_DURATION_MS = 6e5;
    MAX_FAILED_LOGS = 500;
    QUICK_FLUSH_WINDOW_MS = 200;
    EVENT_LOGGER_MAP = {};
    RetryFailedLogsTrigger = {
      Startup: "startup",
      GainedFocus: "gained_focus"
    };
    EventLogger = class _EventLogger {
      constructor(_sdkKey, _emitter, _network, _options) {
        this._sdkKey = _sdkKey;
        this._emitter = _emitter;
        this._network = _network;
        this._options = _options;
        this._queue = [];
        this._lastExposureTimeMap = {};
        this._nonExposedChecks = {};
        this._hasRunQuickFlush = false;
        this._creationTime = Date.now();
        this._loggingEnabled = _options?.loggingEnabled ?? (_options?.disableLogging === true ? LoggingEnabledOption.disabled : LoggingEnabledOption.browserOnly);
        if (_options?.loggingEnabled && _options.disableLogging !== void 0) {
          Log.warn(
            "Detected both loggingEnabled and disableLogging options. loggingEnabled takes precedence - please remove disableLogging."
          );
        }
        this._maxQueueSize = _options?.loggingBufferMaxSize ?? DEFAULT_QUEUE_SIZE;
        const config2 = _options?.networkConfig;
        this._logEventUrlConfig = new UrlConfiguration(
          Endpoint._rgstr,
          config2?.logEventUrl,
          config2?.api,
          config2?.logEventFallbackUrls
        );
      }
      static _safeFlushAndForget(sdkKey) {
        EVENT_LOGGER_MAP[sdkKey]?.flush().catch(() => {
        });
      }
      static _safeRetryFailedLogs(sdkKey) {
        EVENT_LOGGER_MAP[sdkKey]?._retryFailedLogs(
          RetryFailedLogsTrigger.GainedFocus
        );
      }
      setLogEventCompressionMode(mode) {
        this._network.setLogEventCompressionMode(mode);
      }
      setLoggingEnabled(loggingEnabled) {
        this._loggingEnabled = loggingEnabled;
      }
      enqueue(event) {
        if (!this._shouldLogEvent(event)) {
          return;
        }
        this._normalizeAndAppendEvent(event);
        this._quickFlushIfNeeded();
        if (this._queue.length > this._maxQueueSize) {
          _EventLogger._safeFlushAndForget(this._sdkKey);
        }
      }
      incrementNonExposureCount(name) {
        const current2 = this._nonExposedChecks[name] ?? 0;
        this._nonExposedChecks[name] = current2 + 1;
      }
      reset() {
        this.flush().catch(() => {
        });
        this._lastExposureTimeMap = {};
      }
      start() {
        const isServerEnv = _isServerEnv();
        if (isServerEnv && this._options?.loggingEnabled !== "always") {
          return;
        }
        EVENT_LOGGER_MAP[this._sdkKey] = this;
        if (!isServerEnv) {
          _subscribeToVisiblityChanged((visibility) => {
            if (visibility === "background") {
              _EventLogger._safeFlushAndForget(this._sdkKey);
            } else if (visibility === "foreground") {
              _EventLogger._safeRetryFailedLogs(this._sdkKey);
            }
          });
        }
        this._retryFailedLogs(RetryFailedLogsTrigger.Startup);
        this._startBackgroundFlushInterval();
      }
      async stop() {
        if (this._flushIntervalId) {
          clearInterval(this._flushIntervalId);
          this._flushIntervalId = null;
        }
        delete EVENT_LOGGER_MAP[this._sdkKey];
        await this.flush();
      }
      async flush() {
        this._appendAndResetNonExposedChecks();
        if (this._queue.length === 0) {
          return;
        }
        const events = this._queue;
        this._queue = [];
        await this._sendEvents(events);
      }
      /**
       * We 'Quick Flush' following the very first event enqueued
       * within the quick flush window
       */
      _quickFlushIfNeeded() {
        if (this._hasRunQuickFlush) {
          return;
        }
        this._hasRunQuickFlush = true;
        if (Date.now() - this._creationTime > QUICK_FLUSH_WINDOW_MS) {
          return;
        }
        setTimeout(
          () => _EventLogger._safeFlushAndForget(this._sdkKey),
          QUICK_FLUSH_WINDOW_MS
        );
      }
      _shouldLogEvent(event) {
        if (this._options?.loggingEnabled !== "always" && _isServerEnv()) {
          return false;
        }
        if (!_isExposureEvent(event)) {
          return true;
        }
        const user = event.user ? event.user : { statsigEnvironment: void 0 };
        const userKey = _getUserStorageKey(this._sdkKey, user);
        const metadata2 = event.metadata ? event.metadata : {};
        const key = [
          event.eventName,
          userKey,
          metadata2["gate"],
          metadata2["config"],
          metadata2["ruleID"],
          metadata2["allocatedExperiment"],
          metadata2["parameterName"],
          String(metadata2["isExplicitParameter"]),
          metadata2["reason"]
        ].join("|");
        const previous = this._lastExposureTimeMap[key];
        const now = Date.now();
        if (previous && now - previous < DEDUPER_WINDOW_DURATION_MS) {
          return false;
        }
        if (Object.keys(this._lastExposureTimeMap).length > MAX_DEDUPER_KEYS) {
          this._lastExposureTimeMap = {};
        }
        this._lastExposureTimeMap[key] = now;
        return true;
      }
      async _sendEvents(events) {
        if (this._loggingEnabled === "disabled") {
          this._saveFailedLogsToStorage(events);
          return false;
        }
        try {
          const isClosing = _isUnloading();
          const shouldUseBeacon = isClosing && this._network.isBeaconSupported() && this._options?.networkConfig?.networkOverrideFunc == null;
          this._emitter({
            name: "pre_logs_flushed",
            events
          });
          const response = shouldUseBeacon ? this._sendEventsViaBeacon(events) : await this._sendEventsViaPost(events);
          if (response.success) {
            this._emitter({
              name: "logs_flushed",
              events
            });
            return true;
          } else {
            Log.warn("Failed to flush events.");
            this._saveFailedLogsToStorage(events);
            return false;
          }
        } catch {
          Log.warn("Failed to flush events.");
          return false;
        }
      }
      async _sendEventsViaPost(events) {
        const result = await this._network.post(this._getRequestData(events));
        const code = result?.code ?? -1;
        return { success: code >= 200 && code < 300 };
      }
      _sendEventsViaBeacon(events) {
        return {
          success: this._network.beacon(this._getRequestData(events))
        };
      }
      _getRequestData(events) {
        return {
          sdkKey: this._sdkKey,
          data: {
            events
          },
          urlConfig: this._logEventUrlConfig,
          retries: 3,
          isCompressable: true,
          params: {
            [NetworkParam.EventCount]: String(events.length)
          },
          credentials: "same-origin"
        };
      }
      _saveFailedLogsToStorage(events) {
        while (events.length > MAX_FAILED_LOGS) {
          events.shift();
        }
        const storageKey = this._getStorageKey();
        try {
          _setObjectInStorage(storageKey, events);
        } catch {
          Log.warn("Unable to save failed logs to storage");
        }
      }
      _retryFailedLogs(trigger) {
        const storageKey = this._getStorageKey();
        (async () => {
          if (!Storage.isReady()) {
            await Storage.isReadyResolver();
          }
          const events = _getObjectFromStorage(storageKey);
          if (!events) {
            return;
          }
          if (trigger === RetryFailedLogsTrigger.Startup) {
            Storage.removeItem(storageKey);
          }
          const isSuccess = await this._sendEvents(events);
          if (isSuccess && trigger === RetryFailedLogsTrigger.GainedFocus) {
            Storage.removeItem(storageKey);
          }
        })().catch(() => {
          Log.warn("Failed to flush stored logs");
        });
      }
      _getStorageKey() {
        return `statsig.failed_logs.${_DJB2(this._sdkKey)}`;
      }
      _normalizeAndAppendEvent(event) {
        if (event.user) {
          event.user = { ...event.user };
          delete event.user.privateAttributes;
        }
        const extras = {};
        const currentPage = this._getCurrentPageUrl();
        if (currentPage) {
          extras.statsigMetadata = { currentPage };
        }
        const final = {
          ...event,
          ...extras
        };
        Log.debug("Enqueued Event:", final);
        this._queue.push(final);
      }
      _appendAndResetNonExposedChecks() {
        if (Object.keys(this._nonExposedChecks).length === 0) {
          return;
        }
        this._normalizeAndAppendEvent({
          eventName: "statsig::non_exposed_checks",
          user: null,
          time: Date.now(),
          metadata: {
            checks: { ...this._nonExposedChecks }
          }
        });
        this._nonExposedChecks = {};
      }
      _getCurrentPageUrl() {
        if (this._options?.includeCurrentPageUrlWithEvents === false) {
          return;
        }
        return _getCurrentPageUrlSafe();
      }
      _startBackgroundFlushInterval() {
        const flushInterval = this._options?.loggingIntervalMs ?? DEFAULT_FLUSH_INTERVAL_MS;
        const intervalId = setInterval(() => {
          const logger = EVENT_LOGGER_MAP[this._sdkKey];
          if (!logger || logger._flushIntervalId !== intervalId) {
            clearInterval(intervalId);
          } else {
            _EventLogger._safeFlushAndForget(this._sdkKey);
          }
        }, flushInterval);
        if (intervalId.unref) {
          intervalId.unref();
        }
        this._flushIntervalId = intervalId;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigMetadata.ts
var SDK_VERSION, metadata, StatsigMetadataProvider;
var init_StatsigMetadata = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigMetadata.ts"() {
    "use strict";
    SDK_VERSION = "3.20.3";
    metadata = {
      sdkVersion: SDK_VERSION,
      sdkType: "js-mono"
      // js-mono is overwritten by Precomp and OnDevice clients
    };
    StatsigMetadataProvider = {
      get: () => metadata,
      add: (additions) => {
        metadata = { ...metadata, ...additions };
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/ClientInterfaces.ts
var init_ClientInterfaces = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/ClientInterfaces.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/UUID.ts
function getUUID() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  let d = (/* @__PURE__ */ new Date()).getTime();
  let d2 = typeof performance !== "undefined" && performance.now && performance.now() * 1e3 || 0;
  const y = "89ab"[Math.floor(Math.random() * 4)];
  return `xxxxxxxx-xxxx-4xxx-${y}xxx-xxxxxxxxxxxx`.replace(/[xy]/g, (c) => {
    let r = Math.random() * 16;
    if (d > 0) {
      r = (d + r) % 16 | 0;
      d = Math.floor(d / 16);
    } else {
      r = (d2 + r) % 16 | 0;
      d2 = Math.floor(d2 / 16);
    }
    return (c === "x" ? r : r & 7 | 8).toString(16);
  });
}
var init_UUID = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/UUID.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StableID.ts
function _getStableIDStorageKey(sdkKey) {
  return `statsig.stable_id.${_getStorageKey(sdkKey)}`;
}
function _persistToStorage(stableID, sdkKey) {
  const storageKey = _getStableIDStorageKey(sdkKey);
  try {
    _setObjectInStorage(storageKey, stableID);
  } catch (e) {
    Log.warn("Failed to save StableID to storage");
  }
}
function _loadFromStorage(sdkKey) {
  const storageKey = _getStableIDStorageKey(sdkKey);
  return _getObjectFromStorage(storageKey);
}
function _loadFromCookie(sdkKey) {
  if (!COOKIE_ENABLED_MAP[sdkKey] || _getDocumentSafe() == null) {
    return null;
  }
  const cookies = document.cookie.split(";");
  for (const cookie of cookies) {
    const [key, value] = cookie.trim().split("=");
    if (key === _getCookieName(sdkKey)) {
      return decodeURIComponent(value);
    }
  }
  return null;
}
function _persistToCookie(stableID, sdkKey) {
  if (!COOKIE_ENABLED_MAP[sdkKey] || !document) {
    return;
  }
  const expiryDate = /* @__PURE__ */ new Date();
  expiryDate.setFullYear(expiryDate.getFullYear() + 1);
  document.cookie = `${_getCookieName(sdkKey)}=${encodeURIComponent(stableID)}; expires=${expiryDate.toUTCString()}; path=/`;
}
function _getCookieName(sdkKey) {
  return `statsig.stable_id.${_getStorageKey(sdkKey)}`;
}
var PROMISE_MAP, COOKIE_ENABLED_MAP, DISABLED_MAP, StableID;
var init_StableID = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StableID.ts"() {
    "use strict";
    init_CacheKey();
    init_Log();
    init_SafeJs();
    init_StorageProvider();
    init_UUID();
    PROMISE_MAP = {};
    COOKIE_ENABLED_MAP = {};
    DISABLED_MAP = {};
    StableID = {
      cookiesEnabled: false,
      randomID: Math.random().toString(36),
      get: (sdkKey) => {
        if (DISABLED_MAP[sdkKey]) {
          return null;
        }
        if (PROMISE_MAP[sdkKey] != null) {
          return PROMISE_MAP[sdkKey];
        }
        let stableID = null;
        stableID = _loadFromCookie(sdkKey);
        if (stableID != null) {
          PROMISE_MAP[sdkKey] = stableID;
          _persistToStorage(stableID, sdkKey);
          return stableID;
        }
        stableID = _loadFromStorage(sdkKey);
        if (stableID == null) {
          stableID = getUUID();
        }
        _persistToStorage(stableID, sdkKey);
        _persistToCookie(stableID, sdkKey);
        PROMISE_MAP[sdkKey] = stableID;
        return stableID;
      },
      setOverride: (override, sdkKey) => {
        PROMISE_MAP[sdkKey] = override;
        _persistToStorage(override, sdkKey);
        _persistToCookie(override, sdkKey);
      },
      _setCookiesEnabled: (sdkKey, cookiesEnabled) => {
        COOKIE_ENABLED_MAP[sdkKey] = cookiesEnabled;
      },
      _setDisabled: (sdkKey, disabled) => {
        DISABLED_MAP[sdkKey] = disabled;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigUser.ts
function _normalizeUser(original, options, fallbackEnvironment) {
  try {
    const copy = JSON.parse(JSON.stringify(original));
    if (options != null && options.environment != null) {
      copy.statsigEnvironment = options.environment;
    } else if (fallbackEnvironment != null) {
      copy.statsigEnvironment = { tier: fallbackEnvironment };
    }
    return copy;
  } catch (error) {
    Log.error("Failed to JSON.stringify user");
    return { statsigEnvironment: void 0 };
  }
}
function _getFullUserHash(user) {
  return user ? _DJB2Object(user) : null;
}
var init_StatsigUser = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigUser.ts"() {
    "use strict";
    init_Hashing();
    init_Log();
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/TypedJsonParse.ts
function _typedJsonParse(data, guard, typeName) {
  try {
    const result = JSON.parse(data);
    if (result && typeof result === "object" && guard in result) {
      return result;
    }
  } catch {
  }
  Log.error(`Failed to parse ${typeName}`);
  return null;
}
var init_TypedJsonParse = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/TypedJsonParse.ts"() {
    "use strict";
    init_Log();
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/DataAdapterCore.ts
function _makeDataAdapterResult(source, data, stableID, user) {
  return {
    source,
    data,
    receivedAt: Date.now(),
    stableID,
    fullUserHash: _getFullUserHash(user)
  };
}
function _getEvictableKey(data, limit) {
  const keys = Object.keys(data);
  if (keys.length <= limit) {
    return null;
  }
  return keys.reduce((prevKey, currKey) => {
    const prev = data[prevKey];
    const current2 = data[currKey];
    if (typeof prev === "object" && typeof current2 === "object") {
      return current2.receivedAt < prev.receivedAt ? currKey : prevKey;
    }
    return current2 < prev ? currKey : prevKey;
  });
}
var CACHE_LIMIT, DataAdapterCore, InMemoryCache;
var init_DataAdapterCore = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/DataAdapterCore.ts"() {
    "use strict";
    init_Log();
    init_StableID();
    init_StatsigUser();
    init_StorageProvider();
    init_TypedJsonParse();
    CACHE_LIMIT = 10;
    DataAdapterCore = class {
      constructor(_adapterName, _cacheSuffix) {
        this._adapterName = _adapterName;
        this._cacheSuffix = _cacheSuffix;
        this._options = null;
        this._sdkKey = null;
        this._lastModifiedStoreKey = `statsig.last_modified_time.${_cacheSuffix}`;
        this._inMemoryCache = new InMemoryCache();
      }
      attach(sdkKey, options, _network) {
        this._sdkKey = sdkKey;
        this._options = options;
      }
      getDataSync(user) {
        const normalized = user && _normalizeUser(user, this._options);
        const cacheKey = this._getCacheKey(normalized);
        const inMem = this._inMemoryCache.get(cacheKey, normalized);
        if (inMem && this._getIsCacheValueValid(inMem)) {
          return inMem;
        }
        const cache = this._loadFromCache(cacheKey);
        if (cache && this._getIsCacheValueValid(cache)) {
          this._inMemoryCache.add(cacheKey, cache);
          return this._inMemoryCache.get(cacheKey, normalized);
        }
        return null;
      }
      setData(data, user) {
        const normalized = user && _normalizeUser(user, this._options);
        const cacheKey = this._getCacheKey(normalized);
        this._inMemoryCache.add(
          cacheKey,
          _makeDataAdapterResult("Bootstrap", data, null, normalized)
        );
      }
      _getIsCacheValueValid(current2) {
        return current2.stableID == null || current2.stableID === StableID.get(this._getSdkKey());
      }
      async _getDataAsyncImpl(current2, user, options) {
        if (!Storage.isReady()) {
          await Storage.isReadyResolver();
        }
        const cache = current2 ?? this.getDataSync(user);
        const ops = [this._fetchAndPrepFromNetwork(cache, user, options)];
        if (options?.timeoutMs) {
          ops.push(
            new Promise((r) => setTimeout(r, options.timeoutMs)).then(() => {
              Log.debug("Fetching latest value timed out");
              return null;
            })
          );
        }
        return await Promise.race(ops);
      }
      async _prefetchDataImpl(user, options) {
        const normalized = user && _normalizeUser(user, this._options);
        const cacheKey = this._getCacheKey(normalized);
        const result = await this._getDataAsyncImpl(null, normalized, options);
        if (result) {
          this._inMemoryCache.add(cacheKey, { ...result, source: "Prefetch" });
        }
      }
      async _fetchAndPrepFromNetwork(cachedResult, user, options) {
        const cachedData = cachedResult?.data ?? null;
        const isCacheValidFor204 = cachedResult != null && this._isCachedResultValidFor204(cachedResult, user);
        const latest = await this._fetchFromNetwork(
          cachedData,
          user,
          options,
          isCacheValidFor204
        );
        if (!latest) {
          Log.debug("No response returned for latest value");
          return null;
        }
        const response = _typedJsonParse(
          latest,
          "has_updates",
          "Response"
        );
        const sdkKey = this._getSdkKey();
        const stableID = StableID.get(sdkKey);
        let result = null;
        if (response?.has_updates === true) {
          result = _makeDataAdapterResult("Network", latest, stableID, user);
        } else if (cachedData && response?.has_updates === false) {
          result = _makeDataAdapterResult(
            "NetworkNotModified",
            cachedData,
            stableID,
            user
          );
        } else {
          return null;
        }
        const cacheKey = this._getCacheKey(user);
        this._inMemoryCache.add(cacheKey, result);
        this._writeToCache(cacheKey, result);
        return result;
      }
      _getSdkKey() {
        if (this._sdkKey != null) {
          return this._sdkKey;
        }
        Log.error(`${this._adapterName} is not attached to a Client`);
        return "";
      }
      _loadFromCache(cacheKey) {
        const cache = Storage.getItem?.(cacheKey);
        if (cache == null) {
          return null;
        }
        const result = _typedJsonParse(
          cache,
          "source",
          "Cached Result"
        );
        return result ? { ...result, source: "Cache" } : null;
      }
      _writeToCache(cacheKey, result) {
        Storage.setItem(cacheKey, JSON.stringify(result));
        this._runLocalStorageCacheEviction(cacheKey);
      }
      _runLocalStorageCacheEviction(cacheKey) {
        const lastModifiedTimeMap = _getObjectFromStorage(
          this._lastModifiedStoreKey
        ) ?? {};
        lastModifiedTimeMap[cacheKey] = Date.now();
        const evictable = _getEvictableKey(lastModifiedTimeMap, CACHE_LIMIT);
        if (evictable) {
          delete lastModifiedTimeMap[evictable];
          Storage.removeItem(evictable);
        }
        _setObjectInStorage(this._lastModifiedStoreKey, lastModifiedTimeMap);
      }
    };
    InMemoryCache = class {
      constructor() {
        this._data = {};
      }
      get(cacheKey, user) {
        const result = this._data[cacheKey];
        const cached = result?.stableID;
        const provided = user?.customIDs?.stableID;
        if (provided && cached && provided !== cached) {
          Log.warn("'StatsigUser.customIDs.stableID' mismatch");
          return null;
        }
        return result;
      }
      add(cacheKey, value) {
        const oldest = _getEvictableKey(this._data, CACHE_LIMIT - 1);
        if (oldest) {
          delete this._data[oldest];
        }
        this._data[cacheKey] = value;
      }
      merge(values) {
        this._data = { ...this._data, ...values };
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/DownloadConfigSpecsResponse.ts
var init_DownloadConfigSpecsResponse = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/DownloadConfigSpecsResponse.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/SDKType.ts
var SDK_CLIENT, suffix, SDKType;
var init_SDKType = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/SDKType.ts"() {
    "use strict";
    SDK_CLIENT = {};
    SDKType = {
      _get: (sdkKey) => {
        return (SDK_CLIENT[sdkKey] ?? "js-mono") + (suffix ?? "");
      },
      _setClientType(sdkKey, client) {
        SDK_CLIENT[sdkKey] = client;
      },
      _setBindingType(binding) {
        if (!suffix || suffix === "-react") {
          suffix = "-" + binding;
        }
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/ErrorBoundary.ts
function _resolveError(error) {
  if (error instanceof Error) {
    return error;
  } else if (typeof error === "string") {
    return new Error(error);
  } else {
    return new Error("An unknown error occurred.");
  }
}
function _getDescription(obj) {
  try {
    return JSON.stringify(obj);
  } catch {
    return UNKNOWN_ERROR;
  }
}
function _getAllInstanceMethodNames(instance) {
  const names = /* @__PURE__ */ new Set();
  let proto = Object.getPrototypeOf(instance);
  while (proto && proto !== Object.prototype) {
    Object.getOwnPropertyNames(proto).filter((prop) => typeof proto?.[prop] === "function").forEach((name) => names.add(name));
    proto = Object.getPrototypeOf(proto);
  }
  return Array.from(names);
}
function _getStatsigOptionLoggingCopy(options) {
  if (!options) {
    return {};
  }
  const loggingCopy = {};
  Object.entries(options).forEach(([option, value]) => {
    const valueType = typeof value;
    switch (valueType) {
      case "number":
      case "bigint":
      case "boolean":
        loggingCopy[String(option)] = value;
        break;
      case "string":
        if (value.length < 50) {
          loggingCopy[String(option)] = value;
        } else {
          loggingCopy[String(option)] = "set";
        }
        break;
      case "object":
        if (option === "environment") {
          loggingCopy["environment"] = value;
        } else if (option === "networkConfig") {
          loggingCopy["networkConfig"] = value;
        } else {
          loggingCopy[String(option)] = value != null ? "set" : "unset";
        }
        break;
      default:
    }
  });
  return loggingCopy;
}
var EXCEPTION_ENDPOINT, UNKNOWN_ERROR, ErrorBoundary;
var init_ErrorBoundary = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/ErrorBoundary.ts"() {
    "use strict";
    init_Log();
    init_SDKType();
    init_StatsigMetadata();
    EXCEPTION_ENDPOINT = "https://statsigapi.net/v1/sdk_exception";
    UNKNOWN_ERROR = "[Statsig] UnknownError";
    ErrorBoundary = class {
      constructor(_sdkKey, _options, _emitter, _lastSeenError) {
        this._sdkKey = _sdkKey;
        this._options = _options;
        this._emitter = _emitter;
        this._lastSeenError = _lastSeenError;
        this._seen = /* @__PURE__ */ new Set();
      }
      wrap(instance) {
        try {
          const obj = instance;
          _getAllInstanceMethodNames(obj).forEach((name) => {
            const original = obj[name];
            if ("$EB" in original) {
              return;
            }
            obj[name] = (...args) => {
              return this._capture(name, () => original.apply(instance, args));
            };
            obj[name].$EB = true;
          });
        } catch (err) {
          this._onError("eb:wrap", err);
        }
      }
      logError(tag, error) {
        this._onError(tag, error);
      }
      getLastSeenErrorAndReset() {
        const tempError = this._lastSeenError;
        this._lastSeenError = void 0;
        return tempError ?? null;
      }
      attachErrorIfNoneExists(error) {
        if (this._lastSeenError) {
          return;
        }
        this._lastSeenError = _resolveError(error);
      }
      _capture(tag, task) {
        try {
          const res = task();
          if (res && res instanceof Promise) {
            return res.catch((err) => this._onError(tag, err));
          }
          return res;
        } catch (error) {
          this._onError(tag, error);
          return null;
        }
      }
      _onError(tag, error) {
        try {
          Log.warn(`Caught error in ${tag}`, { error });
          const impl = async () => {
            const unwrapped = error ? error : Error(UNKNOWN_ERROR);
            const isError = unwrapped instanceof Error;
            const name = isError ? unwrapped.name : "No Name";
            const resolvedError = _resolveError(unwrapped);
            this._lastSeenError = resolvedError;
            if (this._seen.has(name)) {
              return;
            }
            this._seen.add(name);
            if (this._options?.networkConfig?.preventAllNetworkTraffic) {
              this._emitter?.({
                name: "error",
                error,
                tag
              });
              return;
            }
            const sdkType = SDKType._get(this._sdkKey);
            const statsigMetadata = StatsigMetadataProvider.get();
            const info = isError ? unwrapped.stack : _getDescription(unwrapped);
            const body = {
              tag,
              exception: name,
              info,
              statsigOptions: _getStatsigOptionLoggingCopy(this._options),
              ...{ ...statsigMetadata, sdkType }
            };
            const func = this._options?.networkConfig?.networkOverrideFunc ?? fetch;
            await func(EXCEPTION_ENDPOINT, {
              method: "POST",
              headers: {
                "STATSIG-API-KEY": this._sdkKey,
                "STATSIG-SDK-TYPE": String(sdkType),
                "STATSIG-SDK-VERSION": String(statsigMetadata.sdkVersion),
                "Content-Type": "application/json"
              },
              body: JSON.stringify(body)
            });
            this._emitter?.({
              name: "error",
              error,
              tag
            });
          };
          impl().then(() => {
          }).catch(() => {
          });
        } catch (_error) {
        }
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/EvaluationOptions.ts
var init_EvaluationOptions = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/EvaluationOptions.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/EvaluationTypes.ts
var init_EvaluationTypes = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/EvaluationTypes.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/InitializeResponse.ts
var init_InitializeResponse = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/InitializeResponse.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/MemoKey.ts
function createMemoKey(prefix, name, options) {
  let cacheKey = `${prefix}|${name}`;
  if (!options) {
    return cacheKey;
  }
  for (const key of Object.keys(options)) {
    if (DO_NOT_MEMO_KEYS.has(key)) {
      return void 0;
    }
    if (EXIST_KEYS.has(key)) {
      cacheKey += `|${key}=true`;
    } else {
      cacheKey += `|${key}=${options[key]}`;
    }
  }
  return cacheKey;
}
var MemoPrefix, EXIST_KEYS, DO_NOT_MEMO_KEYS;
var init_MemoKey = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/MemoKey.ts"() {
    "use strict";
    MemoPrefix = {
      _gate: "g",
      _dynamicConfig: "c",
      _experiment: "e",
      _configList: "cl",
      _layer: "l",
      _paramStore: "p"
    };
    EXIST_KEYS = /* @__PURE__ */ new Set([
      // Add keys that should be memoized based only on their existence, not their value
    ]);
    DO_NOT_MEMO_KEYS = /* @__PURE__ */ new Set([
      // Add keys that if exist, should not be memoized
      "userPersistedValues"
    ]);
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/DnsTxtQuery.ts
async function _fetchTxtRecords(networkFunc) {
  const response = await networkFunc(DNS_QUERY_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/dns-message",
      Accept: "application/dns-message"
    },
    body: FEATURE_ASSETS_DNS_QUERY
  });
  if (!response.ok) {
    const err = new Error("Failed to fetch TXT records from DNS");
    err.name = "DnsTxtFetchError";
    throw err;
  }
  const data = await response.arrayBuffer();
  const bytes = new Uint8Array(data);
  return _parseDnsResponse(bytes);
}
function _parseDnsResponse(input) {
  const start = input.findIndex(
    (byte, index) => index < MAX_START_LOOKUP && String.fromCharCode(byte) === "=" && DOMAIN_CHARS.includes(String.fromCharCode(input[index - 1]))
  );
  if (start === -1) {
    const err = new Error("Failed to parse TXT records from DNS");
    err.name = "DnsTxtParseError";
    throw err;
  }
  let result = "";
  for (let i = start - 1; i < input.length; i++) {
    result += String.fromCharCode(input[i]);
  }
  return result.split(",");
}
var FEATURE_ASSETS_DNS_QUERY, DNS_QUERY_ENDPOINT, DOMAIN_CHARS, MAX_START_LOOKUP;
var init_DnsTxtQuery = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/DnsTxtQuery.ts"() {
    "use strict";
    FEATURE_ASSETS_DNS_QUERY = new Uint8Array([
      0,
      0,
      1,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      13,
      102,
      101,
      97,
      116,
      117,
      114,
      101,
      97,
      115,
      115,
      101,
      116,
      115,
      3,
      111,
      114,
      103,
      0,
      0,
      16,
      0,
      1
    ]);
    DNS_QUERY_ENDPOINT = "https://cloudflare-dns.com/dns-query";
    DOMAIN_CHARS = [
      "i",
      // initialize
      "e",
      // events
      "d"
      // dcs
    ];
    MAX_START_LOOKUP = 200;
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/NetworkFallbackResolver.ts
function _isDomainFailure(errorMsg, timedOut) {
  const lowerErrorMsg = errorMsg?.toLowerCase() ?? "";
  return timedOut || lowerErrorMsg.includes("uncaught exception") || lowerErrorMsg.includes("failed to fetch") || lowerErrorMsg.includes("networkerror when attempting to fetch resource");
}
function _getFallbackInfoStorageKey(sdkKey) {
  return `statsig.network_fallback.${_DJB2(sdkKey)}`;
}
function _tryWriteFallbackInfoToCache(sdkKey, info) {
  const hashKey = _getFallbackInfoStorageKey(sdkKey);
  if (!info || Object.keys(info).length === 0) {
    Storage.removeItem(hashKey);
    return;
  }
  Storage.setItem(hashKey, JSON.stringify(info));
}
function _readFallbackInfoFromCache(sdkKey) {
  const hashKey = _getFallbackInfoStorageKey(sdkKey);
  const data = Storage.getItem(hashKey);
  if (!data) {
    return null;
  }
  try {
    return JSON.parse(data);
  } catch {
    Log.error("Failed to parse FallbackInfo");
    return null;
  }
}
function _extractPathFromUrl(urlString) {
  try {
    const url = new URL(urlString);
    return url.pathname;
  } catch (error) {
    return null;
  }
}
var DEFAULT_TTL_MS, COOLDOWN_TIME_MS, NetworkFallbackResolver;
var init_NetworkFallbackResolver = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/NetworkFallbackResolver.ts"() {
    "use strict";
    init_DnsTxtQuery();
    init_Hashing();
    init_Log();
    init_StorageProvider();
    DEFAULT_TTL_MS = 7 * 24 * 60 * 60 * 1e3;
    COOLDOWN_TIME_MS = 4 * 60 * 60 * 1e3;
    NetworkFallbackResolver = class {
      constructor(options) {
        this._fallbackInfo = null;
        this._errorBoundary = null;
        this._dnsQueryCooldowns = {};
        this._networkOverrideFunc = options.networkConfig?.networkOverrideFunc;
      }
      setErrorBoundary(errorBoundary) {
        this._errorBoundary = errorBoundary;
      }
      tryBumpExpiryTime(sdkKey, urlConfig) {
        const info = this._fallbackInfo?.[urlConfig.endpoint];
        if (!info) {
          return;
        }
        info.expiryTime = Date.now() + DEFAULT_TTL_MS;
        _tryWriteFallbackInfoToCache(sdkKey, {
          ...this._fallbackInfo,
          [urlConfig.endpoint]: info
        });
      }
      getActiveFallbackUrl(sdkKey, urlConfig) {
        if (urlConfig.customUrl != null && urlConfig.fallbackUrls != null) {
          return null;
        }
        let info = this._fallbackInfo;
        if (info == null) {
          info = _readFallbackInfoFromCache(sdkKey) ?? {};
          this._fallbackInfo = info;
        }
        const entry = info[urlConfig.endpoint];
        if (!entry || Date.now() > (entry.expiryTime ?? 0) || urlConfig.getChecksum() !== entry.urlConfigChecksum) {
          delete info[urlConfig.endpoint];
          this._fallbackInfo = info;
          _tryWriteFallbackInfoToCache(sdkKey, this._fallbackInfo);
          return null;
        }
        if (entry.url) {
          return entry.url;
        }
        return null;
      }
      async tryFetchUpdatedFallbackInfo(sdkKey, urlConfig, errorMessage, timedOut) {
        try {
          if (!_isDomainFailure(errorMessage, timedOut)) {
            return false;
          }
          const canUseNetworkFallbacks = urlConfig.customUrl == null && urlConfig.fallbackUrls == null;
          const urls = canUseNetworkFallbacks ? await this._tryFetchFallbackUrlsFromNetwork(urlConfig) : urlConfig.fallbackUrls;
          const newUrl = this._pickNewFallbackUrl(
            this._fallbackInfo?.[urlConfig.endpoint],
            urls
          );
          if (!newUrl) {
            return false;
          }
          this._updateFallbackInfoWithNewUrl(sdkKey, urlConfig, newUrl);
          return true;
        } catch (error) {
          this._errorBoundary?.logError("tryFetchUpdatedFallbackInfo", error);
          return false;
        }
      }
      _updateFallbackInfoWithNewUrl(sdkKey, urlConfig, newUrl) {
        const newFallbackInfo = {
          urlConfigChecksum: urlConfig.getChecksum(),
          url: newUrl,
          expiryTime: Date.now() + DEFAULT_TTL_MS,
          previous: []
        };
        const endpoint = urlConfig.endpoint;
        const previousInfo = this._fallbackInfo?.[endpoint];
        if (previousInfo) {
          newFallbackInfo.previous.push(...previousInfo.previous);
        }
        if (newFallbackInfo.previous.length > 10) {
          newFallbackInfo.previous = [];
        }
        const previousUrl = this._fallbackInfo?.[endpoint]?.url;
        if (previousUrl != null) {
          newFallbackInfo.previous.push(previousUrl);
        }
        this._fallbackInfo = {
          ...this._fallbackInfo,
          [endpoint]: newFallbackInfo
        };
        _tryWriteFallbackInfoToCache(sdkKey, this._fallbackInfo);
      }
      async _tryFetchFallbackUrlsFromNetwork(urlConfig) {
        const cooldown = this._dnsQueryCooldowns[urlConfig.endpoint];
        if (cooldown && Date.now() < cooldown) {
          return null;
        }
        this._dnsQueryCooldowns[urlConfig.endpoint] = Date.now() + COOLDOWN_TIME_MS;
        const result = [];
        const records = await _fetchTxtRecords(this._networkOverrideFunc ?? fetch);
        const path = _extractPathFromUrl(urlConfig.defaultUrl);
        for (const record of records) {
          if (!record.startsWith(urlConfig.endpointDnsKey + "=")) {
            continue;
          }
          const parts = record.split("=");
          if (parts.length > 1) {
            let baseUrl = parts[1];
            if (baseUrl.endsWith("/")) {
              baseUrl = baseUrl.slice(0, -1);
            }
            result.push(`https://${baseUrl}${path}`);
          }
        }
        return result;
      }
      _pickNewFallbackUrl(currentFallbackInfo, urls) {
        if (urls == null) {
          return null;
        }
        const previouslyUsed = new Set(currentFallbackInfo?.previous ?? []);
        const currentFallbackUrl = currentFallbackInfo?.url;
        let found = null;
        for (const loopUrl of urls) {
          const url = loopUrl.endsWith("/") ? loopUrl.slice(0, -1) : loopUrl;
          if (!previouslyUsed.has(loopUrl) && url !== currentFallbackUrl) {
            found = url;
            break;
          }
        }
        return found;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/SDKFlags.ts
var FLAGMAP, SDKFlags;
var init_SDKFlags = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/SDKFlags.ts"() {
    "use strict";
    FLAGMAP = {};
    SDKFlags = {
      setFlags: (sdkKey, flags) => {
        FLAGMAP[sdkKey] = flags;
      },
      get: (sdkKey, flagKey) => {
        return FLAGMAP[sdkKey]?.[flagKey] ?? false;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/SessionID.ts
function _loadSession(sdkKey) {
  let data = _loadFromStorage2(sdkKey);
  const now = Date.now();
  if (!data) {
    data = {
      sessionID: getUUID(),
      startTime: now,
      lastUpdate: now
    };
  }
  return {
    data,
    sdkKey
  };
}
function _overrideSessionId(override, sdkKey) {
  const now = Date.now();
  return {
    data: {
      sessionID: override,
      startTime: now,
      lastUpdate: now
    },
    sdkKey
  };
}
function _bumpSession(session) {
  const now = Date.now();
  const data = session.data;
  const sdkKey = session.sdkKey;
  if (_isIdle(data) || _hasRunTooLong(data)) {
    data.sessionID = getUUID();
    data.startTime = now;
    const client = __STATSIG__?.instance(sdkKey);
    if (client) {
      client.$emt({ name: "session_expired" });
    }
  }
  data.lastUpdate = now;
  _persistToStorage2(data, session.sdkKey);
  clearTimeout(session.idleTimeoutID);
  clearTimeout(session.ageTimeoutID);
  const lifetime = now - data.startTime;
  session.idleTimeoutID = _createSessionTimeout(sdkKey, MAX_SESSION_IDLE_TIME);
  session.ageTimeoutID = _createSessionTimeout(
    sdkKey,
    MAX_SESSION_AGE - lifetime
  );
  return session;
}
function _createSessionTimeout(sdkKey, duration) {
  return setTimeout(() => {
    const client = _getStatsigGlobal()?.instance(sdkKey);
    if (client) {
      client.$emt({ name: "session_expired" });
    }
  }, duration);
}
function _isIdle({ lastUpdate }) {
  return Date.now() - lastUpdate > MAX_SESSION_IDLE_TIME;
}
function _hasRunTooLong({ startTime }) {
  return Date.now() - startTime > MAX_SESSION_AGE;
}
function _getSessionIDStorageKey(sdkKey) {
  return `statsig.session_id.${_getStorageKey(sdkKey)}`;
}
function _persistToStorage2(session, sdkKey) {
  const storageKey = _getSessionIDStorageKey(sdkKey);
  try {
    _setObjectInStorage(storageKey, session);
  } catch (e) {
    Log.warn("Failed to save SessionID");
  }
}
function _loadFromStorage2(sdkKey) {
  const storageKey = _getSessionIDStorageKey(sdkKey);
  return _getObjectFromStorage(storageKey);
}
var MAX_SESSION_IDLE_TIME, MAX_SESSION_AGE, PROMISE_MAP2, SessionID, StatsigSession;
var init_SessionID = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/SessionID.ts"() {
    "use strict";
    init_StatsigGlobal();
    init_CacheKey();
    init_Log();
    init_StorageProvider();
    init_UUID();
    MAX_SESSION_IDLE_TIME = 30 * 60 * 1e3;
    MAX_SESSION_AGE = 4 * 60 * 60 * 1e3;
    PROMISE_MAP2 = {};
    SessionID = {
      get: (sdkKey) => {
        return StatsigSession.get(sdkKey).data.sessionID;
      }
    };
    StatsigSession = {
      get: (sdkKey) => {
        if (PROMISE_MAP2[sdkKey] == null) {
          PROMISE_MAP2[sdkKey] = _loadSession(sdkKey);
        }
        const session = PROMISE_MAP2[sdkKey];
        return _bumpSession(session);
      },
      overrideInitialSessionID: (override, sdkKey) => {
        PROMISE_MAP2[sdkKey] = _overrideSessionId(override, sdkKey);
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigClientEventEmitter.ts
var ErrorTag;
var init_StatsigClientEventEmitter = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigClientEventEmitter.ts"() {
    "use strict";
    ErrorTag = {
      NetworkError: "NetworkError"
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/NetworkCore.ts
function _allowCompression(args, options) {
  if (!args.isCompressable) {
    return false;
  }
  if (_getStatsigGlobalFlag("no-compress") != null || typeof CompressionStream === "undefined" || typeof TextEncoder === "undefined") {
    return false;
  }
  const isProxy = args.urlConfig.customUrl != null || args.urlConfig.fallbackUrls != null;
  const flagEnabled = SDKFlags.get(args.sdkKey, "enable_log_event_compression") === true;
  switch (options.logEventCompressionMode) {
    case LogEventCompressionMode.Disabled:
      return false;
    case LogEventCompressionMode.Enabled:
      if (isProxy && !flagEnabled) {
        return false;
      }
      return true;
    case LogEventCompressionMode.Forced:
      return true;
    default:
      return false;
  }
}
function _getErrorMessage(controller, error) {
  if (controller?.signal.aborted && typeof controller.signal.reason === "string") {
    return controller.signal.reason;
  }
  if (typeof error === "string") {
    return error;
  }
  if (error instanceof Error) {
    return `${error.name}: ${error.message}`;
  }
  return "Unknown Error";
}
function _didTimeout(controller) {
  const timeout = controller?.signal.aborted && typeof controller.signal.reason === "string" && controller.signal.reason.includes("Timeout");
  return timeout || false;
}
function _tryMarkInitStart(args, attempt) {
  if (args.urlConfig.endpoint !== Endpoint._initialize) {
    return;
  }
  Diagnostics._markInitNetworkReqStart(args.sdkKey, {
    attempt
  });
}
function _tryMarkInitEnd(args, response, attempt, body, err) {
  if (args.urlConfig.endpoint !== Endpoint._initialize) {
    return;
  }
  Diagnostics._markInitNetworkReqEnd(
    args.sdkKey,
    Diagnostics._getDiagnosticsData(response, attempt, body, err)
  );
}
async function _exponentialBackoff(attempt) {
  await new Promise(
    (r) => setTimeout(
      r,
      Math.min(BACKOFF_BASE_MS * (attempt * attempt), BACKOFF_MAX_MS)
    )
  );
}
var DEFAULT_TIMEOUT_MS, BACKOFF_BASE_MS, BACKOFF_MAX_MS, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX_REQ_COUNT, LEAK_RATE, RETRYABLE_CODES, NetworkCore, _ensureValidSdkKey, _populateRequestBody;
var init_NetworkCore = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/NetworkCore.ts"() {
    "use strict";
    init_StatsigGlobal();
    init_StatsigGlobal();
    init_Diagnostics();
    init_Log();
    init_NetworkConfig();
    init_NetworkFallbackResolver();
    init_SDKFlags();
    init_SDKType();
    init_SafeJs();
    init_SessionID();
    init_StableID();
    init_StatsigClientEventEmitter();
    init_StatsigMetadata();
    init_StatsigOptionsCommon();
    init_VisibilityObserving();
    DEFAULT_TIMEOUT_MS = 1e4;
    BACKOFF_BASE_MS = 500;
    BACKOFF_MAX_MS = 3e4;
    RATE_LIMIT_WINDOW_MS = 1e3;
    RATE_LIMIT_MAX_REQ_COUNT = 50;
    LEAK_RATE = RATE_LIMIT_MAX_REQ_COUNT / RATE_LIMIT_WINDOW_MS;
    RETRYABLE_CODES = /* @__PURE__ */ new Set([408, 500, 502, 503, 504, 522, 524, 599]);
    NetworkCore = class {
      constructor(options, _emitter) {
        this._emitter = _emitter;
        this._errorBoundary = null;
        this._timeout = DEFAULT_TIMEOUT_MS;
        this._netConfig = {};
        this._options = {};
        this._leakyBucket = {};
        this._lastUsedInitUrl = null;
        if (options) {
          this._options = options;
        }
        if (this._options.networkConfig) {
          this._netConfig = this._options.networkConfig;
        }
        if (this._netConfig.networkTimeoutMs) {
          this._timeout = this._netConfig.networkTimeoutMs;
        }
        this._fallbackResolver = new NetworkFallbackResolver(this._options);
        this.setLogEventCompressionMode(this._getLogEventCompressionMode(options));
      }
      setLogEventCompressionMode(mode) {
        this._options.logEventCompressionMode = mode;
      }
      setErrorBoundary(errorBoundary) {
        this._errorBoundary = errorBoundary;
        this._errorBoundary.wrap(this);
        this._errorBoundary.wrap(this._fallbackResolver);
        this._fallbackResolver.setErrorBoundary(errorBoundary);
      }
      isBeaconSupported() {
        return typeof navigator !== "undefined" && typeof navigator.sendBeacon === "function";
      }
      getLastUsedInitUrlAndReset() {
        const tempUrl = this._lastUsedInitUrl;
        this._lastUsedInitUrl = null;
        return tempUrl;
      }
      beacon(args) {
        if (!_ensureValidSdkKey(args)) {
          return false;
        }
        const argsInternal = this._getInternalRequestArgs("POST", args);
        const url = this._getPopulatedURL(argsInternal);
        const nav = navigator;
        return nav.sendBeacon.bind(nav)(url, argsInternal.body);
      }
      async post(args) {
        const argsInternal = this._getInternalRequestArgs("POST", args);
        this._tryEncodeBody(argsInternal);
        await this._tryToCompressBody(argsInternal);
        return this._sendRequest(argsInternal);
      }
      get(args) {
        const argsInternal = this._getInternalRequestArgs("GET", args);
        return this._sendRequest(argsInternal);
      }
      async _sendRequest(args) {
        if (!_ensureValidSdkKey(args)) {
          return null;
        }
        if (this._netConfig.preventAllNetworkTraffic) {
          return null;
        }
        const { method, body, retries, attempt } = args;
        const endpoint = args.urlConfig.endpoint;
        if (this._isRateLimited(endpoint)) {
          Log.warn(
            `Request to ${endpoint} was blocked because you are making requests too frequently.`
          );
          return null;
        }
        const currentAttempt = attempt ?? 1;
        const abortController = typeof AbortController !== "undefined" ? new AbortController() : null;
        const timeoutHandle = setTimeout(() => {
          abortController?.abort(`Timeout of ${this._timeout}ms expired.`);
        }, this._timeout);
        const populatedUrl = this._getPopulatedURL(args);
        let response = null;
        const keepalive = _isUnloading();
        try {
          const config2 = {
            method,
            body,
            headers: {
              ...args.headers
            },
            signal: abortController?.signal,
            priority: args.priority,
            keepalive
          };
          _tryMarkInitStart(args, currentAttempt);
          const bucket = this._leakyBucket[endpoint];
          if (bucket) {
            bucket.lastRequestTime = Date.now();
            this._leakyBucket[endpoint] = bucket;
          }
          const func = this._netConfig.networkOverrideFunc ?? fetch;
          response = await func(populatedUrl, config2);
          clearTimeout(timeoutHandle);
          if (!response.ok) {
            const text2 = await response.text().catch(() => "No Text");
            const err = new Error(`NetworkError: ${populatedUrl} ${text2}`);
            err.name = "NetworkError";
            throw err;
          }
          const text = await response.text();
          _tryMarkInitEnd(args, response, currentAttempt, text);
          this._fallbackResolver.tryBumpExpiryTime(args.sdkKey, args.urlConfig);
          return {
            body: text,
            code: response.status
          };
        } catch (error) {
          const errorMessage = _getErrorMessage(abortController, error);
          const timedOut = _didTimeout(abortController);
          _tryMarkInitEnd(args, response, currentAttempt, "", error);
          const fallbackUpdated = await this._fallbackResolver.tryFetchUpdatedFallbackInfo(
            args.sdkKey,
            args.urlConfig,
            errorMessage,
            timedOut
          );
          if (fallbackUpdated) {
            args.fallbackUrl = this._fallbackResolver.getActiveFallbackUrl(
              args.sdkKey,
              args.urlConfig
            );
          }
          if (!retries || currentAttempt > retries || !RETRYABLE_CODES.has(response?.status ?? 500)) {
            this._emitter?.({
              name: "error",
              error,
              tag: ErrorTag.NetworkError,
              requestArgs: args
            });
            const formattedErrorMsg = `A networking error occurred during ${method} request to ${populatedUrl}.`;
            Log.error(formattedErrorMsg, errorMessage, error);
            this._errorBoundary?.attachErrorIfNoneExists(formattedErrorMsg);
            return null;
          }
          await _exponentialBackoff(currentAttempt);
          return this._sendRequest({
            ...args,
            retries,
            attempt: currentAttempt + 1
          });
        }
      }
      _getLogEventCompressionMode(options) {
        let compressionMode = options?.logEventCompressionMode;
        if (!compressionMode && options?.disableCompression === true) {
          compressionMode = LogEventCompressionMode.Disabled;
        }
        if (!compressionMode) {
          compressionMode = LogEventCompressionMode.Enabled;
        }
        return compressionMode;
      }
      _isRateLimited(endpoint) {
        const now = Date.now();
        const bucket = this._leakyBucket[endpoint] ?? {
          count: 0,
          lastRequestTime: now
        };
        const elapsed = now - bucket.lastRequestTime;
        const leakedRequests = Math.floor(elapsed * LEAK_RATE);
        bucket.count = Math.max(0, bucket.count - leakedRequests);
        if (bucket.count >= RATE_LIMIT_MAX_REQ_COUNT) {
          return true;
        }
        bucket.count += 1;
        bucket.lastRequestTime = now;
        this._leakyBucket[endpoint] = bucket;
        return false;
      }
      _getPopulatedURL(args) {
        const url = args.fallbackUrl ?? args.urlConfig.getUrl();
        if (args.urlConfig.endpoint === Endpoint._initialize || args.urlConfig.endpoint === Endpoint._download_config_specs) {
          this._lastUsedInitUrl = url;
        }
        const params = {
          [NetworkParam.SdkKey]: args.sdkKey,
          [NetworkParam.SdkType]: SDKType._get(args.sdkKey),
          [NetworkParam.SdkVersion]: SDK_VERSION,
          [NetworkParam.Time]: String(Date.now()),
          [NetworkParam.SessionID]: SessionID.get(args.sdkKey),
          ...args.params
        };
        const query = Object.keys(params).map((key) => {
          return `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`;
        }).join("&");
        return `${url}${query ? `?${query}` : ""}`;
      }
      _tryEncodeBody(args) {
        const win = _getWindowSafe();
        const body = args.body;
        if (!args.isStatsigEncodable || this._options.disableStatsigEncoding || typeof body !== "string" || _getStatsigGlobalFlag("no-encode") != null || !win?.btoa) {
          return;
        }
        try {
          args.body = win.btoa(body).split("").reverse().join("");
          args.params = {
            ...args.params ?? {},
            [NetworkParam.StatsigEncoded]: "1"
          };
        } catch (e) {
          Log.warn(`Request encoding failed for ${args.urlConfig.getUrl()}`, e);
        }
      }
      async _tryToCompressBody(args) {
        const body = args.body;
        if (typeof body !== "string" || !_allowCompression(args, this._options)) {
          return;
        }
        try {
          const bytes = new TextEncoder().encode(body);
          const stream = new CompressionStream("gzip");
          const writer = stream.writable.getWriter();
          writer.write(bytes).catch(Log.error);
          writer.close().catch(Log.error);
          const reader = stream.readable.getReader();
          const chunks = [];
          let result;
          while (!(result = await reader.read()).done) {
            chunks.push(result.value);
          }
          const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
          const combined = new Uint8Array(totalLength);
          let offset = 0;
          for (const chunk of chunks) {
            combined.set(chunk, offset);
            offset += chunk.length;
          }
          args.body = combined;
          args.params = {
            ...args.params ?? {},
            [NetworkParam.IsGzipped]: "1"
          };
        } catch (e) {
          Log.warn(`Request compression failed for ${args.urlConfig.getUrl()}`, e);
        }
      }
      _getInternalRequestArgs(method, args) {
        const fallbackUrl = this._fallbackResolver.getActiveFallbackUrl(
          args.sdkKey,
          args.urlConfig
        );
        const result = {
          ...args,
          method,
          fallbackUrl
        };
        if ("data" in args) {
          _populateRequestBody(result, args.data);
        }
        return result;
      }
    };
    _ensureValidSdkKey = (args) => {
      if (!args.sdkKey) {
        Log.warn("Unable to make request without an SDK key");
        return false;
      }
      return true;
    };
    _populateRequestBody = (args, data) => {
      const { sdkKey, fallbackUrl } = args;
      const stableID = StableID.get(sdkKey);
      const sessionID = SessionID.get(sdkKey);
      const sdkType = SDKType._get(sdkKey);
      args.body = JSON.stringify({
        ...data,
        statsigMetadata: {
          ...StatsigMetadataProvider.get(),
          stableID,
          sessionID,
          sdkType,
          fallbackUrl
        }
      });
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/OverrideAdapter.ts
var init_OverrideAdapter = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/OverrideAdapter.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/ParamStoreTypes.ts
var init_ParamStoreTypes = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/ParamStoreTypes.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/SizeOf.ts
var CURLY_AND_SQUARE_BRACKET_SIZE, APPROX_ADDITIONAL_SIZE, _fastApproxSizeOf;
var init_SizeOf = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/SizeOf.ts"() {
    "use strict";
    CURLY_AND_SQUARE_BRACKET_SIZE = 2;
    APPROX_ADDITIONAL_SIZE = 1;
    _fastApproxSizeOf = (obj, max) => {
      let size = 0;
      const keys = Object.keys(obj);
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        const value = obj[key];
        size += key.length;
        if (typeof value === "object" && value !== null) {
          size += _fastApproxSizeOf(value, max) + CURLY_AND_SQUARE_BRACKET_SIZE;
        } else {
          size += String(value).length + APPROX_ADDITIONAL_SIZE;
        }
        if (size >= max) {
          return size;
        }
      }
      return size;
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigClientBase.ts
function _assignGlobalInstance(sdkKey, client) {
  if (_isServerEnv()) {
    return;
  }
  const statsigGlobal2 = _getStatsigGlobal();
  const instances = statsigGlobal2.instances ?? {};
  const inst = client;
  if (instances[sdkKey] != null) {
    Log.warn(
      "Creating multiple Statsig clients with the same SDK key can lead to unexpected behavior. Multi-instance support requires different SDK keys."
    );
  }
  instances[sdkKey] = inst;
  if (!statsigGlobal2.firstInstance) {
    statsigGlobal2.firstInstance = inst;
  }
  statsigGlobal2.instances = instances;
  __STATSIG__ = statsigGlobal2;
}
var MAX_MEMO_CACHE_SIZE, StatsigClientBase;
var init_StatsigClientBase = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigClientBase.ts"() {
    "use strict";
    init_StatsigGlobal();
    init_StatsigGlobal();
    init_ErrorBoundary();
    init_EventLogger();
    init_Log();
    init_MemoKey();
    init_SafeJs();
    init_SessionID();
    init_StableID();
    init_StatsigOptionsCommon();
    init_StorageProvider();
    MAX_MEMO_CACHE_SIZE = 3e3;
    StatsigClientBase = class {
      constructor(sdkKey, adapter, network, options) {
        this.loadingStatus = "Uninitialized";
        this._initializePromise = null;
        this._listeners = {};
        const emitter = this.$emt.bind(this);
        options?.logLevel != null && (Log.level = options.logLevel);
        options?.disableStorage && Storage._setDisabled(true);
        options?.initialSessionID && StatsigSession.overrideInitialSessionID(options.initialSessionID, sdkKey);
        options?.storageProvider && Storage._setProvider(options.storageProvider);
        options?.enableCookies && StableID._setCookiesEnabled(sdkKey, options.enableCookies);
        options?.disableStableID && StableID._setDisabled(sdkKey, true);
        this._sdkKey = sdkKey;
        this._options = options ?? {};
        this._memoCache = {};
        this.overrideAdapter = options?.overrideAdapter ?? null;
        this._logger = new EventLogger(sdkKey, emitter, network, options);
        this._errorBoundary = new ErrorBoundary(sdkKey, options, emitter);
        this._errorBoundary.wrap(this);
        this._errorBoundary.wrap(adapter);
        this._errorBoundary.wrap(this._logger);
        network.setErrorBoundary(this._errorBoundary);
        this.dataAdapter = adapter;
        this.dataAdapter.attach(sdkKey, options, network);
        this.storageProvider = Storage;
        this.overrideAdapter?.loadFromStorage?.()?.catch((e) => this._errorBoundary.logError("OA::loadFromStorage", e));
        this._primeReadyRipcord();
        _assignGlobalInstance(sdkKey, this);
      }
      /**
       * Updates runtime configuration options for the SDK, allowing toggling of certain behaviors such as logging and storage to comply with user preferences or regulations such as GDPR.
       *
       * @param {StatsigRuntimeMutableOptions} options - The configuration options that dictate the runtime behavior of the SDK.
       */
      updateRuntimeOptions(options) {
        if (options.loggingEnabled) {
          this._options.loggingEnabled = options.loggingEnabled;
          this._logger.setLoggingEnabled(options.loggingEnabled);
        } else if (options.disableLogging != null) {
          this._options.disableLogging = options.disableLogging;
          this._logger.setLoggingEnabled(
            options.disableLogging ? "disabled" : "browser-only"
          );
        }
        if (options.disableStorage != null) {
          this._options.disableStorage = options.disableStorage;
          Storage._setDisabled(options.disableStorage);
        }
        if (options.enableCookies != null) {
          this._options.enableCookies = options.enableCookies;
          StableID._setCookiesEnabled(this._sdkKey, options.enableCookies);
        }
        if (options.logEventCompressionMode) {
          this._logger.setLogEventCompressionMode(options.logEventCompressionMode);
        } else if (options.disableCompression) {
          this._logger.setLogEventCompressionMode(LogEventCompressionMode.Disabled);
        }
      }
      /**
       * Flushes any currently queued events.
       */
      flush() {
        return this._logger.flush();
      }
      /**
       * Gracefully shuts down the SDK, ensuring that all pending events are send before the SDK stops.
       * This function emits a 'pre_shutdown' event and then waits for the logger to complete its shutdown process.
       *
       * @returns {Promise<void>} A promise that resolves when all shutdown procedures, including logging shutdown, have been completed.
       */
      async shutdown() {
        this.$emt({ name: "pre_shutdown" });
        this._setStatus("Uninitialized", null);
        this._initializePromise = null;
        await this._logger.stop();
      }
      /**
       * Subscribes a callback function to a specific {@link StatsigClientEvent} or all StatsigClientEvents if the wildcard '*' is used.
       * Once subscribed, the listener callback will be invoked whenever the specified event is emitted.
       *
       * @param {StatsigClientEventName} event - The name of the event to subscribe to, or '*' to subscribe to all events.
       * @param {StatsigClientEventCallback<T>} listener - The callback function to execute when the event occurs. The function receives event-specific data as its parameter.
       * @see {@link off} for unsubscribing from events.
       */
      on(event, listener) {
        if (!this._listeners[event]) {
          this._listeners[event] = [];
        }
        this._listeners[event].push(listener);
      }
      /**
       * Unsubscribes a previously registered callback function from a specific {@link StatsigClientEvent} or all StatsigClientEvents if the wildcard '*' is used.
       *
       * @param {StatsigClientEventName} event - The name of the event from which to unsubscribe, or '*' to unsubscribe from all events.
       * @param {StatsigClientEventCallback<T>} listener - The callback function to remove from the event's notification list.
       * @see {@link on} for subscribing to events.
       */
      off(event, listener) {
        if (this._listeners[event]) {
          const index = this._listeners[event].indexOf(listener);
          if (index !== -1) {
            this._listeners[event].splice(index, 1);
          }
        }
      }
      $on(event, listener) {
        listener.__isInternal = true;
        this.on(event, listener);
      }
      $emt(event) {
        const barrier = (listener) => {
          try {
            listener(event);
          } catch (error) {
            if (listener.__isInternal === true) {
              this._errorBoundary.logError(`__emit:${event.name}`, error);
              return;
            }
            Log.error(
              `An error occurred in a StatsigClientEvent listener. This is not an issue with Statsig.`,
              event
            );
          }
        };
        if (this._listeners[event.name]) {
          this._listeners[event.name].forEach(
            (l) => barrier(l)
          );
        }
        this._listeners["*"]?.forEach(barrier);
      }
      _setStatus(newStatus, values) {
        this.loadingStatus = newStatus;
        this._memoCache = {};
        this.$emt({ name: "values_updated", status: newStatus, values });
      }
      _enqueueExposure(name, exposure, options) {
        if (options?.disableExposureLog === true) {
          this._logger.incrementNonExposureCount(name);
          return;
        }
        this._logger.enqueue(exposure);
      }
      _memoize(prefix, fn) {
        return (name, options) => {
          if (this._options.disableEvaluationMemoization) {
            return fn(name, options);
          }
          const memoKey = createMemoKey(prefix, name, options);
          if (!memoKey) {
            return fn(name, options);
          }
          if (!(memoKey in this._memoCache)) {
            if (Object.keys(this._memoCache).length >= MAX_MEMO_CACHE_SIZE) {
              this._memoCache = {};
            }
            this._memoCache[memoKey] = fn(name, options);
          }
          return this._memoCache[memoKey];
        };
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigDataAdapter.ts
var DataAdapterCachePrefix;
var init_StatsigDataAdapter = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigDataAdapter.ts"() {
    "use strict";
    DataAdapterCachePrefix = "statsig.cached";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigPlugin.ts
var init_StatsigPlugin = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigPlugin.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigTypeFactories.ts
function _makeEvaluation(name, details, evaluation, value) {
  return {
    name,
    details,
    ruleID: evaluation?.rule_id ?? "",
    __evaluation: evaluation,
    value
  };
}
function _makeFeatureGate(name, details, evaluation) {
  return {
    ..._makeEvaluation(name, details, evaluation, evaluation?.value === true),
    idType: evaluation?.id_type ?? null
  };
}
function _makeDynamicConfig(name, details, evaluation) {
  const value = evaluation?.value ?? {};
  return {
    ..._makeEvaluation(name, details, evaluation, value),
    get: _makeTypedGet(name, evaluation?.value)
  };
}
function _makeExperiment(name, details, evaluation) {
  const result = _makeDynamicConfig(name, details, evaluation);
  return {
    ...result,
    groupName: evaluation?.group_name ?? null
  };
}
function _makeLayer(name, details, evaluation, exposeFunc) {
  return {
    ..._makeEvaluation(name, details, evaluation, void 0),
    get: _makeTypedGet(name, evaluation?.value, exposeFunc),
    groupName: evaluation?.group_name ?? null,
    __value: evaluation?.value ?? {}
  };
}
function _mergeOverride(original, overridden, value, exposeFunc) {
  return {
    ...original,
    ...overridden,
    get: _makeTypedGet(original.name, value, exposeFunc)
  };
}
function _makeTypedGet(name, value, exposeFunc) {
  return (param, fallback) => {
    const found = value?.[param] ?? null;
    if (found == null) {
      return fallback ?? null;
    }
    if (fallback != null && !_isTypeMatch(found, fallback)) {
      Log.warn(
        `Parameter type mismatch. '${name}.${param}' was found to be type '${typeof found}' but fallback/return type is '${typeof fallback}'. See https://docs.statsig.com/client/javascript-sdk/#typed-getters`
      );
      return fallback ?? null;
    }
    exposeFunc?.(param);
    return found;
  };
}
var init_StatsigTypeFactories = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigTypeFactories.ts"() {
    "use strict";
    init_Log();
    init_TypingUtils();
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigTypes.ts
var init_StatsigTypes = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigTypes.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/StatsigUpdateDetails.ts
var createUpdateDetails, UPDATE_DETAIL_ERROR_MESSAGES;
var init_StatsigUpdateDetails = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/StatsigUpdateDetails.ts"() {
    "use strict";
    createUpdateDetails = (success, source, initDuration, error, sourceUrl, warnings) => {
      return {
        duration: initDuration,
        source,
        success,
        error,
        sourceUrl,
        warnings
      };
    };
    UPDATE_DETAIL_ERROR_MESSAGES = {
      NO_NETWORK_DATA: "No data was returned from the network. This may be due to a network timeout if a timeout value was specified in the options or ad blocker error."
    };
  }
});

// ../../private-js-client-monorepo/packages/client-core/src/index.ts
var src_exports = {};
__export(src_exports, {
  DataAdapterCachePrefix: () => DataAdapterCachePrefix,
  DataAdapterCore: () => DataAdapterCore,
  Diagnostics: () => Diagnostics,
  EXCEPTION_ENDPOINT: () => EXCEPTION_ENDPOINT,
  Endpoint: () => Endpoint,
  ErrorBoundary: () => ErrorBoundary,
  ErrorTag: () => ErrorTag,
  EventLogger: () => EventLogger,
  Log: () => Log,
  LogEventCompressionMode: () => LogEventCompressionMode,
  LogLevel: () => LogLevel,
  LoggingEnabledOption: () => LoggingEnabledOption,
  MemoPrefix: () => MemoPrefix,
  NetworkCore: () => NetworkCore,
  NetworkDefault: () => NetworkDefault,
  NetworkParam: () => NetworkParam,
  SDKFlags: () => SDKFlags,
  SDKType: () => SDKType,
  SDK_VERSION: () => SDK_VERSION,
  SessionID: () => SessionID,
  StableID: () => StableID,
  StatsigClientBase: () => StatsigClientBase,
  StatsigMetadataProvider: () => StatsigMetadataProvider,
  StatsigSession: () => StatsigSession,
  Storage: () => Storage,
  UPDATE_DETAIL_ERROR_MESSAGES: () => UPDATE_DETAIL_ERROR_MESSAGES,
  UrlConfiguration: () => UrlConfiguration,
  _DJB2: () => _DJB2,
  _DJB2Object: () => _DJB2Object,
  _addDocumentEventListenerSafe: () => _addDocumentEventListenerSafe,
  _addWindowEventListenerSafe: () => _addWindowEventListenerSafe,
  _createConfigExposure: () => _createConfigExposure,
  _createGateExposure: () => _createGateExposure,
  _createLayerParameterExposure: () => _createLayerParameterExposure,
  _fastApproxSizeOf: () => _fastApproxSizeOf,
  _getCurrentPageUrlSafe: () => _getCurrentPageUrlSafe,
  _getDocumentSafe: () => _getDocumentSafe,
  _getFullUserHash: () => _getFullUserHash,
  _getInstance: () => _getInstance,
  _getObjectFromStorage: () => _getObjectFromStorage,
  _getSortedObject: () => _getSortedObject,
  _getStatsigGlobal: () => _getStatsigGlobal,
  _getStatsigGlobalFlag: () => _getStatsigGlobalFlag,
  _getStorageKey: () => _getStorageKey,
  _getUnloadEvent: () => _getUnloadEvent,
  _getUserStorageKey: () => _getUserStorageKey,
  _getWindowSafe: () => _getWindowSafe,
  _isCurrentlyVisible: () => _isCurrentlyVisible,
  _isExposureEvent: () => _isExposureEvent,
  _isServerEnv: () => _isServerEnv,
  _isTypeMatch: () => _isTypeMatch,
  _isUnloading: () => _isUnloading,
  _makeDataAdapterResult: () => _makeDataAdapterResult,
  _makeDynamicConfig: () => _makeDynamicConfig,
  _makeExperiment: () => _makeExperiment,
  _makeFeatureGate: () => _makeFeatureGate,
  _makeLayer: () => _makeLayer,
  _makeTypedGet: () => _makeTypedGet,
  _mapExposures: () => _mapExposures,
  _mergeOverride: () => _mergeOverride,
  _normalizeUser: () => _normalizeUser,
  _notifyVisibilityChanged: () => _notifyVisibilityChanged,
  _setObjectInStorage: () => _setObjectInStorage,
  _subscribeToVisiblityChanged: () => _subscribeToVisiblityChanged,
  _typeOf: () => _typeOf,
  _typedJsonParse: () => _typedJsonParse,
  createMemoKey: () => createMemoKey,
  createUpdateDetails: () => createUpdateDetails,
  getUUID: () => getUUID
});
var init_src = __esm({
  "../../private-js-client-monorepo/packages/client-core/src/index.ts"() {
    "use strict";
    init_StatsigGlobal();
    init_StatsigGlobal();
    init_Diagnostics();
    init_EventLogger();
    init_Log();
    init_StatsigMetadata();
    init_StorageProvider();
    init_StatsigGlobal();
    init_CacheKey();
    init_ClientInterfaces();
    init_DataAdapterCore();
    init_Diagnostics();
    init_DownloadConfigSpecsResponse();
    init_ErrorBoundary();
    init_EvaluationOptions();
    init_EvaluationTypes();
    init_Hashing();
    init_InitializeResponse();
    init_Log();
    init_MemoKey();
    init_NetworkConfig();
    init_NetworkCore();
    init_OverrideAdapter();
    init_ParamStoreTypes();
    init_SafeJs();
    init_SDKType();
    init_SessionID();
    init_SizeOf();
    init_StableID();
    init_StatsigClientBase();
    init_StatsigClientEventEmitter();
    init_StatsigDataAdapter();
    init_StatsigEvent();
    init_StatsigMetadata();
    init_StatsigOptionsCommon();
    init_StatsigPlugin();
    init_StatsigTypeFactories();
    init_StatsigTypes();
    init_StatsigUser();
    init_StorageProvider();
    init_TypedJsonParse();
    init_TypingUtils();
    init_UrlConfiguration();
    init_UUID();
    init_VisibilityObserving();
    init_StatsigUpdateDetails();
    init_SDKFlags();
    Object.assign(_getStatsigGlobal(), { Log, SDK_VERSION });
  }
});

// ../../private-js-client-monorepo/packages/sha256/src/sha256.ts
function SHA256(input) {
  return new Sha256().update(input);
}
var EXTRA, SHIFT, K, Sha256;
var init_sha256 = __esm({
  "../../private-js-client-monorepo/packages/sha256/src/sha256.ts"() {
    "use strict";
    EXTRA = [-2147483648, 8388608, 32768, 128];
    SHIFT = [24, 16, 8, 0];
    K = [
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ];
    Sha256 = class {
      constructor() {
        this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        this.h0 = 1779033703;
        this.h1 = 3144134277;
        this.h2 = 1013904242;
        this.h3 = 2773480762;
        this.h4 = 1359893119;
        this.h5 = 2600822924;
        this.h6 = 528734635;
        this.h7 = 1541459225;
        this.block = this.start = this.bytes = this.hBytes = 0;
        this.finalized = this.hashed = false;
        this.first = true;
        this.lastByteIndex = -1;
      }
      update(message) {
        if (this.finalized) {
          return this;
        }
        if (typeof message !== "string") {
          throw new Error('Must be of type "string"');
        }
        let code;
        let index = 0;
        let i;
        const length = message.length, blocks = this.blocks;
        while (index < length) {
          if (this.hashed) {
            this.hashed = false;
            blocks[0] = this.block;
            blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
          }
          for (i = this.start; index < length && i < 64; ++index) {
            code = message.charCodeAt(index);
            if (code < 128) {
              blocks[i >> 2] |= code << SHIFT[i++ & 3];
            } else if (code < 2048) {
              blocks[i >> 2] |= (192 | code >> 6) << SHIFT[i++ & 3];
              blocks[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
            } else if (code < 55296 || code >= 57344) {
              blocks[i >> 2] |= (224 | code >> 12) << SHIFT[i++ & 3];
              blocks[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
              blocks[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
            } else {
              code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++index) & 1023);
              blocks[i >> 2] |= (240 | code >> 18) << SHIFT[i++ & 3];
              blocks[i >> 2] |= (128 | code >> 12 & 63) << SHIFT[i++ & 3];
              blocks[i >> 2] |= (128 | code >> 6 & 63) << SHIFT[i++ & 3];
              blocks[i >> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
            }
          }
          this.lastByteIndex = i;
          this.bytes += i - this.start;
          if (i >= 64) {
            this.block = blocks[16];
            this.start = i - 64;
            this.hash();
            this.hashed = true;
          } else {
            this.start = i;
          }
        }
        if (this.bytes > 4294967295) {
          this.hBytes += this.bytes / 4294967296 << 0;
          this.bytes = this.bytes % 4294967296;
        }
        return this;
      }
      finalize() {
        if (this.finalized) {
          return;
        }
        this.finalized = true;
        const blocks = this.blocks, i = this.lastByteIndex;
        blocks[16] = this.block;
        blocks[i >> 2] |= EXTRA[i & 3];
        this.block = blocks[16];
        if (i >= 56) {
          if (!this.hashed) {
            this.hash();
          }
          blocks[0] = this.block;
          blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
        }
        blocks[14] = this.hBytes << 3 | this.bytes >>> 29;
        blocks[15] = this.bytes << 3;
        this.hash();
      }
      hash() {
        const blocks = this.blocks;
        let a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4, f = this.h5, g = this.h6, h = this.h7, j, s0, s1, maj, t1, t2, ch, ab, da, cd, bc;
        for (j = 16; j < 64; ++j) {
          t1 = blocks[j - 15];
          s0 = (t1 >>> 7 | t1 << 25) ^ (t1 >>> 18 | t1 << 14) ^ t1 >>> 3;
          t1 = blocks[j - 2];
          s1 = (t1 >>> 17 | t1 << 15) ^ (t1 >>> 19 | t1 << 13) ^ t1 >>> 10;
          blocks[j] = blocks[j - 16] + s0 + blocks[j - 7] + s1 << 0;
        }
        bc = b & c;
        for (j = 0; j < 64; j += 4) {
          if (this.first) {
            ab = 704751109;
            t1 = blocks[0] - 210244248;
            h = t1 - 1521486534 << 0;
            d = t1 + 143694565 << 0;
            this.first = false;
          } else {
            s0 = (a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10);
            s1 = (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7);
            ab = a & b;
            maj = ab ^ a & c ^ bc;
            ch = e & f ^ ~e & g;
            t1 = h + s1 + ch + K[j] + blocks[j];
            t2 = s0 + maj;
            h = d + t1 << 0;
            d = t1 + t2 << 0;
          }
          s0 = (d >>> 2 | d << 30) ^ (d >>> 13 | d << 19) ^ (d >>> 22 | d << 10);
          s1 = (h >>> 6 | h << 26) ^ (h >>> 11 | h << 21) ^ (h >>> 25 | h << 7);
          da = d & a;
          maj = da ^ d & b ^ ab;
          ch = h & e ^ ~h & f;
          t1 = g + s1 + ch + K[j + 1] + blocks[j + 1];
          t2 = s0 + maj;
          g = c + t1 << 0;
          c = t1 + t2 << 0;
          s0 = (c >>> 2 | c << 30) ^ (c >>> 13 | c << 19) ^ (c >>> 22 | c << 10);
          s1 = (g >>> 6 | g << 26) ^ (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7);
          cd = c & d;
          maj = cd ^ c & a ^ da;
          ch = g & h ^ ~g & e;
          t1 = f + s1 + ch + K[j + 2] + blocks[j + 2];
          t2 = s0 + maj;
          f = b + t1 << 0;
          b = t1 + t2 << 0;
          s0 = (b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10);
          s1 = (f >>> 6 | f << 26) ^ (f >>> 11 | f << 21) ^ (f >>> 25 | f << 7);
          bc = b & c;
          maj = bc ^ b & d ^ cd;
          ch = f & g ^ ~f & h;
          t1 = e + s1 + ch + K[j + 3] + blocks[j + 3];
          t2 = s0 + maj;
          e = a + t1 << 0;
          a = t1 + t2 << 0;
          /* @__PURE__ */ (function(_a) {
          })(a);
        }
        this.h0 = this.h0 + a << 0;
        this.h1 = this.h1 + b << 0;
        this.h2 = this.h2 + c << 0;
        this.h3 = this.h3 + d << 0;
        this.h4 = this.h4 + e << 0;
        this.h5 = this.h5 + f << 0;
        this.h6 = this.h6 + g << 0;
        this.h7 = this.h7 + h << 0;
      }
      arrayBuffer() {
        return this._getOutputs().buffer;
      }
      dataView() {
        return this._getOutputs().dataView;
      }
      _getOutputs() {
        this.finalize();
        const buffer = new ArrayBuffer(32);
        const dataView = new DataView(buffer);
        dataView.setUint32(0, this.h0);
        dataView.setUint32(4, this.h1);
        dataView.setUint32(8, this.h2);
        dataView.setUint32(12, this.h3);
        dataView.setUint32(16, this.h4);
        dataView.setUint32(20, this.h5);
        dataView.setUint32(24, this.h6);
        dataView.setUint32(28, this.h7);
        return { dataView, buffer };
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/sha256/src/index.ts
var init_src2 = __esm({
  "../../private-js-client-monorepo/packages/sha256/src/index.ts"() {
    "use strict";
    init_sha256();
  }
});

// ../../private-js-client-monorepo/packages/on-device-eval-core/src/EvaluationComparison.ts
function _startOfDay(date) {
  date.setUTCHours(0, 0, 0, 0);
  return date.getTime();
}
var EvaluationComparison_default;
var init_EvaluationComparison = __esm({
  "../../private-js-client-monorepo/packages/on-device-eval-core/src/EvaluationComparison.ts"() {
    "use strict";
    EvaluationComparison_default = {
      compareNumbers(left, right, operator) {
        if (left == null || right == null) {
          return false;
        }
        const numA = Number(left);
        const numB = Number(right);
        if (isNaN(numA) || isNaN(numB)) {
          return false;
        }
        switch (operator) {
          case "gt":
            return left > right;
          case "gte":
            return left >= right;
          case "lt":
            return left < right;
          case "lte":
            return left <= right;
          default:
            return false;
        }
      },
      compareVersions(left, right, operator) {
        if (left == null || right == null) {
          return false;
        }
        let leftStr = String(left);
        let rightStr = String(right);
        const removeSuffix = (str) => {
          const index = str.indexOf("-");
          return index !== -1 ? str.substring(0, index) : str;
        };
        leftStr = removeSuffix(leftStr);
        rightStr = removeSuffix(rightStr);
        const comparison = (leftStr2, rightStr2) => {
          const leftParts = leftStr2.split(".").map((part) => parseInt(part));
          const rightParts = rightStr2.split(".").map((part) => parseInt(part));
          let i = 0;
          while (i < Math.max(leftParts.length, rightParts.length)) {
            const leftCount = i < leftParts.length ? leftParts[i] : 0;
            const rightCount = i < rightParts.length ? rightParts[i] : 0;
            if (leftCount < rightCount) {
              return -1;
            }
            if (leftCount > rightCount) {
              return 1;
            }
            i++;
          }
          return 0;
        };
        const result = comparison(leftStr, rightStr);
        switch (operator) {
          case "version_gt":
            return result > 0;
          case "version_gte":
            return result >= 0;
          case "version_lt":
            return result < 0;
          case "version_lte":
            return result <= 0;
          case "version_eq":
            return result === 0;
          case "version_neq":
            return result !== 0;
          default:
            return false;
        }
      },
      compareStringInArray(value, array, operator) {
        if (!Array.isArray(array)) {
          return false;
        }
        const ignoreCase = operator !== "any_case_sensitive" && operator !== "none_case_sensitive";
        const result = array.findIndex((current2) => {
          const valueString = String(value);
          const currentString = String(current2);
          const left = ignoreCase ? valueString.toLowerCase() : valueString;
          const right = ignoreCase ? currentString.toLowerCase() : currentString;
          switch (operator) {
            case "any":
            case "none":
            case "any_case_sensitive":
            case "none_case_sensitive":
              return left === right;
            case "str_starts_with_any":
              return left.startsWith(right);
            case "str_ends_with_any":
              return left.endsWith(right);
            case "str_contains_any":
            case "str_contains_none":
              return left.includes(right);
            default:
              return false;
          }
        }) !== -1;
        switch (operator) {
          case "none":
          case "none_case_sensitive":
          case "str_contains_none":
            return !result;
          default:
            return result;
        }
      },
      compareStringWithRegEx(value, target) {
        try {
          const valueString = String(value);
          if (valueString.length < 1e3) {
            return new RegExp(String(target)).test(valueString);
          }
        } catch (e) {
        }
        return false;
      },
      compareTime(left, right, operator) {
        if (left == null || right == null) {
          return false;
        }
        try {
          let dateLeft = new Date(String(left));
          if (isNaN(dateLeft.getTime())) {
            dateLeft = new Date(Number(left));
          }
          let dateRight = new Date(String(right));
          if (isNaN(dateRight.getTime())) {
            dateRight = new Date(Number(right));
          }
          const timeLeft = dateLeft.getTime();
          const timeRight = dateRight.getTime();
          if (isNaN(timeLeft) || isNaN(timeRight)) {
            return false;
          }
          switch (operator) {
            case "before":
              return timeLeft < timeRight;
            case "after":
              return timeLeft > timeRight;
            case "on":
              return _startOfDay(dateLeft) === _startOfDay(dateRight);
            default:
              return false;
          }
        } catch (e) {
          return false;
        }
      },
      arrayHasValue(value, target) {
        const valueSet = new Set(value);
        for (let i = 0; i < target.length; i++) {
          if (valueSet.has(target[i]) || valueSet.has(parseFloat(target[i]))) {
            return true;
          }
        }
        return false;
      },
      arrayHasAllValues(value, target) {
        const valueSet = new Set(value);
        for (let i = 0; i < target.length; i++) {
          if (!valueSet.has(target[i]) && !valueSet.has(parseFloat(target[i]))) {
            return false;
          }
        }
        return true;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/on-device-eval-core/src/EvaluationResult.ts
function makeEvalResult(overrides) {
  const base = {
    unsupported: false,
    bool_value: false,
    rule_id: "",
    secondary_exposures: [],
    json_value: {},
    explicit_parameters: null,
    allocated_experiment_name: null,
    is_experiment_group: false,
    group_name: null,
    undelegated_secondary_exposures: void 0
  };
  return { ...base, ...overrides };
}
function resultToGateEval(spec, result) {
  return {
    name: spec.name,
    id_type: spec.idType,
    rule_id: result.rule_id,
    value: result.bool_value,
    secondary_exposures: result.secondary_exposures,
    version: spec.version?.toString()
  };
}
function resultToConfigEval(spec, result) {
  return {
    name: spec.name,
    id_type: spec.idType,
    rule_id: result.rule_id,
    value: result.json_value,
    secondary_exposures: result.secondary_exposures,
    group: result.group_name ?? "",
    group_name: result.group_name ?? void 0,
    is_device_based: false,
    is_experiment_active: spec.isActive,
    is_user_in_experiment: result.is_experiment_group,
    version: spec.version?.toString(),
    passed: result.bool_value
  };
}
function resultToLayerEval(layerSpec, experimentSpec, result) {
  return {
    name: layerSpec.name,
    rule_id: result.rule_id,
    value: result.json_value,
    secondary_exposures: result.secondary_exposures,
    undelegated_secondary_exposures: result.undelegated_secondary_exposures,
    allocated_experiment_name: result.allocated_experiment_name ?? "",
    explicit_parameters: result.explicit_parameters ?? [],
    group: result.group_name ?? "",
    group_name: result.group_name ?? void 0,
    is_device_based: false,
    is_experiment_active: experimentSpec?.isActive,
    is_user_in_experiment: result.is_experiment_group,
    version: layerSpec.version?.toString()
  };
}
var init_EvaluationResult = __esm({
  "../../private-js-client-monorepo/packages/on-device-eval-core/src/EvaluationResult.ts"() {
    "use strict";
  }
});

// ../../private-js-client-monorepo/packages/on-device-eval-core/src/Evaluator.ts
function _getUnitIDFromUser(user, idType) {
  if (typeof idType === "string" && idType.toLowerCase() !== "userid") {
    return user.customIDs?.[idType] ?? user?.customIDs?.[idType.toLowerCase()];
  }
  return user.userID;
}
function _evalPassPercent(rule, user, config2) {
  if (rule.passPercentage === 100) {
    return true;
  }
  if (rule.passPercentage === 0) {
    return false;
  }
  const hash = _computeUserHash(
    config2.salt + "." + (rule.salt ?? rule.id) + "." + (_getUnitIDFromUser(user, rule.idType) ?? "")
  );
  return Number(hash % BigInt(CONDITION_SEGMENT_COUNT)) < rule.passPercentage * 100;
}
function _computeUserHash(userHash) {
  const sha256 = SHA256(userHash);
  return sha256.dataView().getBigUint64(0, false);
}
function _getFromEnvironment(user, field) {
  if (field == null) {
    return null;
  }
  return _getParameterCaseInsensitive(user.statsigEnvironment, field);
}
function _getParameterCaseInsensitive(object, key) {
  if (object == null) {
    return void 0;
  }
  const asLowercase = key.toLowerCase();
  const keyMatch = Object.keys(object).find(
    (k) => k.toLowerCase() === asLowercase
  );
  if (keyMatch === void 0) {
    return void 0;
  }
  return object[keyMatch];
}
function _getFromUser(user, field) {
  if (field == null || typeof user !== "object" || user == null) {
    return null;
  }
  const indexableUser = user;
  return indexableUser[field] ?? indexableUser[field.toLowerCase()] ?? user?.custom?.[field] ?? user?.custom?.[field.toLowerCase()] ?? user?.privateAttributes?.[field] ?? user?.privateAttributes?.[field.toLowerCase()];
}
function _isRecord(obj) {
  return obj != null && typeof obj === "object";
}
var CONDITION_SEGMENT_COUNT, USER_BUCKET_COUNT, Evaluator;
var init_Evaluator = __esm({
  "../../private-js-client-monorepo/packages/on-device-eval-core/src/Evaluator.ts"() {
    "use strict";
    init_src2();
    init_EvaluationComparison();
    init_EvaluationResult();
    CONDITION_SEGMENT_COUNT = 10 * 1e3;
    USER_BUCKET_COUNT = 1e3;
    Evaluator = class {
      constructor(_store) {
        this._store = _store;
      }
      evaluateGate(name, user) {
        const { spec, details } = this._getSpecAndDetails("gate", name);
        if (!spec) {
          return { evaluation: null, details };
        }
        const result = this._evaluateSpec(spec, user);
        const evaluation = resultToGateEval(spec, result);
        this._handleUnsupportedEvaluation(result, details);
        return { evaluation, details };
      }
      evaluateConfig(name, user) {
        const { spec, details } = this._getSpecAndDetails("config", name);
        if (!spec) {
          return { evaluation: null, details };
        }
        const result = this._evaluateSpec(spec, user);
        const evaluation = resultToConfigEval(spec, result);
        this._handleUnsupportedEvaluation(result, details);
        return { evaluation, details };
      }
      evaluateLayer(name, user) {
        const { spec, details } = this._getSpecAndDetails("layer", name);
        if (!spec) {
          return { evaluation: null, details };
        }
        const result = this._evaluateSpec(spec, user);
        const experimentName = result?.allocated_experiment_name ?? "";
        const experimentSpec = this._store.getSpecAndSourceInfo(
          "config",
          experimentName
        ).spec;
        const evaluation = resultToLayerEval(spec, experimentSpec, result);
        this._handleUnsupportedEvaluation(result, details);
        return { evaluation, details };
      }
      _handleUnsupportedEvaluation(evaluation, details) {
        if (evaluation.unsupported) {
          details.reason = "Unsupported";
        }
      }
      getParamStoreConfig(name) {
        const paramStoreAndSourceInfo = this._store.getParamStoreAndSourceInfo(name);
        const details = this._getEvaluationDetails(paramStoreAndSourceInfo);
        return {
          config: paramStoreAndSourceInfo.paramStoreConfig ?? null,
          details
        };
      }
      _getSpecAndDetails(kind, name) {
        const specAndSourceInfo = this._store.getSpecAndSourceInfo(kind, name);
        const details = this._getEvaluationDetails(specAndSourceInfo);
        return { details, spec: specAndSourceInfo.spec };
      }
      _getEvaluationDetails(info) {
        const { source, lcut, receivedAt } = info;
        if (source === "Uninitialized" || source === "NoValues") {
          return { reason: source };
        }
        const subreason = ("spec" in info ? info.spec : info.paramStoreConfig) == null ? "Unrecognized" : "Recognized";
        const reason = `${source}:${subreason}`;
        return { reason, lcut, receivedAt };
      }
      _evaluateSpec(spec, user) {
        const defaultValue = _isRecord(spec.defaultValue) ? spec.defaultValue : void 0;
        if (!spec.enabled) {
          return makeEvalResult({
            json_value: defaultValue,
            rule_id: "disabled"
          });
        }
        const exposures = [];
        for (const rule of spec.rules) {
          const result = this._evaluateRule(rule, user);
          if (result.unsupported) {
            return result;
          }
          exposures.push(...result.secondary_exposures);
          if (!result.bool_value) {
            continue;
          }
          const delegateResult = this._evaluateDelegate(
            rule.configDelegate,
            user,
            exposures
          );
          if (delegateResult) {
            return delegateResult;
          }
          const pass = _evalPassPercent(rule, user, spec);
          return makeEvalResult({
            rule_id: result.rule_id,
            bool_value: pass,
            json_value: pass ? result.json_value : defaultValue,
            secondary_exposures: exposures,
            undelegated_secondary_exposures: exposures,
            is_experiment_group: result.is_experiment_group,
            group_name: result.group_name
          });
        }
        return makeEvalResult({
          json_value: defaultValue,
          secondary_exposures: exposures,
          undelegated_secondary_exposures: exposures,
          rule_id: "default"
        });
      }
      _evaluateRule(rule, user) {
        const exposures = [];
        let pass = true;
        for (const condition of rule.conditions) {
          const result = this._evaluateCondition(condition, user);
          if (result.unsupported) {
            return result;
          }
          exposures.push(...result.secondary_exposures);
          if (!result.bool_value) {
            pass = false;
          }
        }
        return makeEvalResult({
          rule_id: rule.id,
          bool_value: pass,
          json_value: _isRecord(rule.returnValue) ? rule.returnValue : void 0,
          secondary_exposures: exposures,
          is_experiment_group: rule.isExperimentGroup === true,
          group_name: rule.groupName
        });
      }
      _evaluateCondition(condition, user) {
        let value = null;
        let pass = false;
        const field = condition.field;
        const target = condition.targetValue;
        const idType = condition.idType;
        const type = condition.type;
        switch (type) {
          case "public":
            return makeEvalResult({ bool_value: true });
          case "pass_gate":
          case "fail_gate": {
            const name = String(target);
            const result = this._evaluateNestedGate(name, user);
            return makeEvalResult({
              bool_value: type === "fail_gate" ? !result.bool_value : result.bool_value,
              secondary_exposures: result.secondary_exposures
            });
          }
          case "multi_pass_gate":
          case "multi_fail_gate":
            return this._evaluateMultiNestedGates(target, type, user);
          case "user_field":
          case "ip_based":
          case "ua_based":
            value = _getFromUser(user, field);
            break;
          case "environment_field":
            value = _getFromEnvironment(user, field);
            break;
          case "current_time":
            value = Date.now();
            break;
          case "user_bucket": {
            const salt = String(condition.additionalValues?.["salt"] ?? "");
            const unitID = _getUnitIDFromUser(user, idType) ?? "";
            const userHash = _computeUserHash(salt + "." + unitID);
            value = Number(userHash % BigInt(USER_BUCKET_COUNT));
            break;
          }
          case "unit_id":
            value = _getUnitIDFromUser(user, idType);
            break;
          default:
            return makeEvalResult({ unsupported: true });
        }
        const operator = condition.operator;
        switch (operator) {
          case "gt":
          case "gte":
          case "lt":
          case "lte":
            pass = EvaluationComparison_default.compareNumbers(value, target, operator);
            break;
          case "version_gt":
          case "version_gte":
          case "version_lt":
          case "version_lte":
          case "version_eq":
          case "version_neq":
            pass = EvaluationComparison_default.compareVersions(value, target, operator);
            break;
          case "any":
          case "none":
          case "str_starts_with_any":
          case "str_ends_with_any":
          case "str_contains_any":
          case "str_contains_none":
          case "any_case_sensitive":
          case "none_case_sensitive":
            pass = EvaluationComparison_default.compareStringInArray(value, target, operator);
            break;
          case "str_matches":
            pass = EvaluationComparison_default.compareStringWithRegEx(value, target);
            break;
          case "before":
          case "after":
          case "on":
            pass = EvaluationComparison_default.compareTime(value, target, operator);
            break;
          case "eq":
            pass = value == target;
            break;
          case "neq":
            pass = value != target;
            break;
          case "in_segment_list":
          case "not_in_segment_list":
            return makeEvalResult({ unsupported: true });
          case "array_contains_any":
          case "array_contains_none": {
            if (!Array.isArray(target)) {
              pass = false;
              break;
            }
            if (!Array.isArray(value)) {
              pass = false;
              break;
            }
            const res = EvaluationComparison_default.arrayHasValue(
              value,
              target
            );
            pass = operator === "array_contains_any" ? res : !res;
            break;
          }
          case "array_contains_all":
          case "not_array_contains_all": {
            if (!Array.isArray(target)) {
              pass = false;
              break;
            }
            if (!Array.isArray(value)) {
              pass = false;
              break;
            }
            const res = EvaluationComparison_default.arrayHasAllValues(
              value,
              target
            );
            pass = operator === "array_contains_all" ? res : !res;
            break;
          }
        }
        return makeEvalResult({ bool_value: pass });
      }
      _evaluateDelegate(configDelegate, user, exposures) {
        if (!configDelegate) {
          return null;
        }
        const { spec } = this._store.getSpecAndSourceInfo("config", configDelegate);
        if (!spec) {
          return null;
        }
        const result = this._evaluateSpec(spec, user);
        return makeEvalResult({
          ...result,
          allocated_experiment_name: configDelegate,
          explicit_parameters: spec.explicitParameters,
          secondary_exposures: exposures.concat(result.secondary_exposures),
          undelegated_secondary_exposures: exposures
        });
      }
      _evaluateNestedGate(name, user) {
        const exposures = [];
        let pass = false;
        const { spec } = this._store.getSpecAndSourceInfo("gate", name);
        if (spec) {
          const result = this._evaluateSpec(spec, user);
          if (result.unsupported) {
            return result;
          }
          pass = result.bool_value;
          exposures.push(...result.secondary_exposures);
          exposures.push({
            gate: name,
            gateValue: String(pass),
            ruleID: result.rule_id
          });
        }
        return makeEvalResult({
          bool_value: pass,
          secondary_exposures: exposures
        });
      }
      _evaluateMultiNestedGates(gates, type, user) {
        if (!Array.isArray(gates)) {
          return makeEvalResult({ unsupported: true });
        }
        const isMultiPassType = type === "multi_pass_gate";
        const exposures = [];
        let pass = false;
        for (const name of gates) {
          if (typeof name !== "string") {
            return makeEvalResult({ unsupported: true });
          }
          const result = this._evaluateNestedGate(name, user);
          if (result.unsupported) {
            return result;
          }
          exposures.push(...result.secondary_exposures);
          if (isMultiPassType ? result.bool_value === true : result.bool_value === false) {
            pass = true;
            break;
          }
        }
        return makeEvalResult({
          bool_value: pass,
          secondary_exposures: exposures
        });
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/on-device-eval-core/src/SpecStore.ts
function _parseResponse(values) {
  return _typedJsonParse(
    values,
    "has_updates",
    "DownloadConfigSpecsResponse"
  );
}
var SpecStore;
var init_SpecStore = __esm({
  "../../private-js-client-monorepo/packages/on-device-eval-core/src/SpecStore.ts"() {
    "use strict";
    init_src();
    SpecStore = class {
      constructor() {
        this._rawValues = null;
        this._values = null;
        this._source = "Uninitialized";
        this._lcut = 0;
        this._receivedAt = 0;
        this._defaultEnvironment = null;
      }
      getValues() {
        return this._rawValues ? _parseResponse(this._rawValues) : null;
      }
      getSource() {
        return this._source;
      }
      getDefaultEnvironment() {
        return this._defaultEnvironment;
      }
      setValuesFromDataAdapter(result) {
        if (!result) {
          return;
        }
        const values = _parseResponse(result.data);
        if (values?.has_updates !== true) {
          return;
        }
        this._lcut = values.time;
        this._receivedAt = result.receivedAt;
        this._source = result.source;
        this._values = values;
        this._rawValues = result.data;
        this._defaultEnvironment = values.default_environment ?? null;
      }
      reset() {
        this._values = null;
        this._rawValues = null;
        this._source = "Loading";
      }
      finalize() {
        if (this._values) {
          return;
        }
        this._source = "NoValues";
      }
      getSpecAndSourceInfo(kind, name) {
        const specs = this._getSpecs(kind);
        return {
          spec: specs?.find((spec) => spec.name === name) ?? null,
          source: this._source,
          lcut: this._lcut,
          receivedAt: this._receivedAt
        };
      }
      getParamStoreAndSourceInfo(name) {
        const paramStores = this._values?.param_stores;
        return {
          paramStoreConfig: paramStores?.[name]?.parameters ?? null,
          source: this._source,
          lcut: this._lcut,
          receivedAt: this._receivedAt
        };
      }
      _getSpecs(kind) {
        switch (kind) {
          case "gate":
            return this._values?.feature_gates;
          case "config":
            return this._values?.dynamic_configs;
          case "layer":
            return this._values?.layer_configs;
        }
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/on-device-eval-core/src/index.ts
var init_src3 = __esm({
  "../../private-js-client-monorepo/packages/on-device-eval-core/src/index.ts"() {
    "use strict";
    init_Evaluator();
    init_SpecStore();
  }
});

// ../../private-js-client-monorepo/packages/js-on-device-eval-client/src/Network.ts
var StatsigNetwork;
var init_Network = __esm({
  "../../private-js-client-monorepo/packages/js-on-device-eval-client/src/Network.ts"() {
    "use strict";
    init_src();
    StatsigNetwork = class extends NetworkCore {
      constructor(options = null) {
        super(options);
        const config2 = options?.networkConfig;
        this._downloadConfigSpecsUrlConfig = new UrlConfiguration(
          Endpoint._download_config_specs,
          config2?.downloadConfigSpecsUrl,
          config2?.api,
          config2?.downloadConfigSpecsFallbackUrls
        );
      }
      async fetchConfigSpecs(sdkKey, priority) {
        const response = await this.get({
          sdkKey,
          urlConfig: this._downloadConfigSpecsUrlConfig,
          priority
        });
        return response?.body ?? null;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/js-on-device-eval-client/src/StatsigSpecsDataAdapter.ts
var StatsigSpecsDataAdapter_exports = {};
__export(StatsigSpecsDataAdapter_exports, {
  StatsigSpecsDataAdapter: () => StatsigSpecsDataAdapter
});
var StatsigSpecsDataAdapter;
var init_StatsigSpecsDataAdapter = __esm({
  "../../private-js-client-monorepo/packages/js-on-device-eval-client/src/StatsigSpecsDataAdapter.ts"() {
    "use strict";
    init_src();
    init_Network();
    StatsigSpecsDataAdapter = class extends DataAdapterCore {
      constructor() {
        super("SpecsDataAdapter", "specs");
        this._network = null;
      }
      attach(sdkKey, options, network) {
        super.attach(sdkKey, options, network);
        if (network !== null && network instanceof StatsigNetwork) {
          this._network = network;
        } else {
          this._network = new StatsigNetwork(options ?? {});
        }
      }
      getDataAsync(current2, options) {
        return this._getDataAsyncImpl(current2, void 0, options);
      }
      prefetchData(options) {
        return this._prefetchDataImpl(void 0, options);
      }
      async _fetchFromNetwork(_current2, _user, options) {
        return await this._network?.fetchConfigSpecs(
          this._getSdkKey(),
          options?.priority
        ) ?? null;
      }
      _getCacheKey() {
        const key = _getStorageKey(this._getSdkKey());
        return `${DataAdapterCachePrefix}.${this._cacheSuffix}.${key}`;
      }
      _isCachedResultValidFor204(result, _user) {
        return result.data.length > 0;
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/js-on-device-eval-client/src/StatsigOnDeviceEvalClient.ts
var StatsigOnDeviceEvalClient_exports = {};
__export(StatsigOnDeviceEvalClient_exports, {
  default: () => StatsigOnDeviceEvalClient
});
var StatsigOnDeviceEvalClient;
var init_StatsigOnDeviceEvalClient = __esm({
  "../../private-js-client-monorepo/packages/js-on-device-eval-client/src/StatsigOnDeviceEvalClient.ts"() {
    "use strict";
    init_src();
    init_src3();
    init_Network();
    init_StatsigSpecsDataAdapter();
    StatsigOnDeviceEvalClient = class _StatsigOnDeviceEvalClient extends StatsigClientBase {
      static instance(sdkKey) {
        const instance = _getStatsigGlobal().instance(sdkKey);
        if (instance instanceof _StatsigOnDeviceEvalClient) {
          return instance;
        }
        Log.warn(
          _isServerEnv() ? "StatsigOnDeviceEvalClient.instance is not supported in server environments" : "Unable to find StatsigOnDeviceEvalClient instance"
        );
        return new _StatsigOnDeviceEvalClient(sdkKey ?? "");
      }
      constructor(sdkKey, options = null) {
        SDKType._setClientType(sdkKey, "js-on-device-eval-client");
        const network = new StatsigNetwork(options);
        super(
          sdkKey,
          options?.dataAdapter ?? new StatsigSpecsDataAdapter(),
          network,
          options
        );
        this._network = network;
        this._store = new SpecStore();
        this._evaluator = new Evaluator(this._store);
        this._sdkInstanceID = getUUID();
      }
      initializeSync(options) {
        if (this.loadingStatus !== "Uninitialized") {
          return {
            success: true,
            duration: 0,
            source: this._store.getSource(),
            sourceUrl: null,
            error: null
          };
        }
        this._logger.start();
        return this.updateSync(options);
      }
      async initializeAsync(options) {
        if (this._initializePromise) {
          return this._initializePromise;
        }
        this._initializePromise = this._initializeAsyncImpl(options);
        return this._initializePromise;
      }
      updateSync(options) {
        const startTime = performance.now();
        this._store.reset();
        const result = this.dataAdapter.getDataSync();
        this._store.setValuesFromDataAdapter(result);
        this._store.finalize();
        this._setStatus("Ready", result);
        if (!options?.disableBackgroundCacheRefresh) {
          this._runPostUpdate(result);
        }
        return createUpdateDetails(
          true,
          this._store.getSource(),
          performance.now() - startTime,
          this._errorBoundary.getLastSeenErrorAndReset(),
          this._network.getLastUsedInitUrlAndReset()
        );
      }
      async updateAsync(options) {
        const startTime = performance.now();
        this._store.reset();
        this._setStatus("Loading", null);
        let result = this.dataAdapter.getDataSync();
        this._store.setValuesFromDataAdapter(result);
        result = await this.dataAdapter.getDataAsync(result, options);
        this._store.setValuesFromDataAdapter(result);
        this._store.finalize();
        this._setStatus("Ready", result);
        return createUpdateDetails(
          true,
          this._store.getSource(),
          performance.now() - startTime,
          this._errorBoundary.getLastSeenErrorAndReset(),
          this._network.getLastUsedInitUrlAndReset()
        );
      }
      getContext() {
        return {
          sdkKey: this._sdkKey,
          options: this._options,
          values: this._store.getValues(),
          errorBoundary: this._errorBoundary,
          session: StatsigSession.get(this._sdkKey),
          stableID: StableID.get(this._sdkKey),
          sdkInstanceID: this._sdkInstanceID
        };
      }
      checkGate(name, user, options) {
        return this.getFeatureGate(name, user, options).value;
      }
      getFeatureGate(name, user, options) {
        const normalized = this._normalizeUser(user);
        const { evaluation, details } = this._evaluator.evaluateGate(
          name,
          normalized
        );
        const gate = _makeFeatureGate(name, details, evaluation);
        this._enqueueExposure(name, _createGateExposure(normalized, gate), options);
        this.$emt({ name: "gate_evaluation", gate });
        return gate;
      }
      getDynamicConfig(name, user, options) {
        const normalized = this._normalizeUser(user);
        const { evaluation, details } = this._evaluator.evaluateConfig(
          name,
          normalized
        );
        const config2 = _makeDynamicConfig(name, details, evaluation);
        const overridden = this.overrideAdapter?.getDynamicConfigOverride?.(
          config2,
          normalized,
          options
        );
        const result = overridden ?? config2;
        this._enqueueExposure(
          name,
          _createConfigExposure(normalized, result),
          options
        );
        this.$emt({ name: "dynamic_config_evaluation", dynamicConfig: result });
        return result;
      }
      getExperiment(name, user, options) {
        const normalized = this._normalizeUser(user);
        const { evaluation, details } = this._evaluator.evaluateConfig(
          name,
          normalized
        );
        const experiment = _makeExperiment(name, details, evaluation);
        const overridden = this.overrideAdapter?.getExperimentOverride?.(
          experiment,
          normalized,
          options
        );
        const result = overridden ?? experiment;
        this._enqueueExposure(
          name,
          _createConfigExposure(normalized, result),
          options
        );
        this.$emt({ name: "experiment_evaluation", experiment: result });
        return result;
      }
      getLayer(name, user, options) {
        const normalized = this._normalizeUser(user);
        const { evaluation, details } = this._evaluator.evaluateLayer(
          name,
          normalized
        );
        const layer = _makeLayer(name, details, evaluation, (param) => {
          this._enqueueExposure(
            name,
            _createLayerParameterExposure(normalized, layer, param),
            options
          );
        });
        const overridden = this.overrideAdapter?.getLayerOverride?.(
          layer,
          normalized,
          options
        );
        const result = overridden ?? layer;
        this.$emt({ name: "layer_evaluation", layer: result });
        return result;
      }
      logEvent(eventOrName, user, value, metadata2) {
        const event = typeof eventOrName === "string" ? {
          eventName: eventOrName,
          value,
          metadata: metadata2
        } : eventOrName;
        this._logger.enqueue({
          ...event,
          user: this._normalizeUser(user),
          time: Date.now()
        });
      }
      _primeReadyRipcord() {
        this.$on("error", () => {
          this.loadingStatus === "Loading" && this._finalizeUpdate(null);
        });
      }
      async _initializeAsyncImpl(options) {
        if (!Storage.isReady()) {
          await Storage.isReadyResolver();
        }
        this._logger.start();
        return this.updateAsync(options);
      }
      _finalizeUpdate(values) {
        this._store.finalize();
        this._setStatus("Ready", values);
      }
      _normalizeUser(user) {
        return _normalizeUser(
          user,
          this._options,
          this._store.getDefaultEnvironment()
        );
      }
      _runPostUpdate(current2) {
        this.dataAdapter.getDataAsync(current2, { priority: "low" }).catch((err) => {
          Log.error("An error occurred after update.", err);
        });
      }
    };
  }
});

// ../../private-js-client-monorepo/packages/js-on-device-eval-client/src/index.js
var require_src = __commonJS({
  "../../private-js-client-monorepo/packages/js-on-device-eval-client/src/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.StatsigSpecsDataAdapter = exports.StatsigOnDeviceEvalClient = void 0;
    var client_core_1 = (init_src(), __toCommonJS(src_exports));
    var StatsigOnDeviceEvalClient_1 = (init_StatsigOnDeviceEvalClient(), __toCommonJS(StatsigOnDeviceEvalClient_exports));
    exports.StatsigOnDeviceEvalClient = StatsigOnDeviceEvalClient_1.default;
    var StatsigSpecsDataAdapter_1 = (init_StatsigSpecsDataAdapter(), __toCommonJS(StatsigSpecsDataAdapter_exports));
    Object.defineProperty(exports, "StatsigSpecsDataAdapter", { enumerable: true, get: function() {
      return StatsigSpecsDataAdapter_1.StatsigSpecsDataAdapter;
    } });
    var __STATSIG__2 = Object.assign((0, client_core_1._getStatsigGlobal)(), {
      StatsigSpecsDataAdapter: StatsigSpecsDataAdapter_1.StatsigSpecsDataAdapter,
      StatsigOnDeviceEvalClient: StatsigOnDeviceEvalClient_1.default
    });
    exports.default = __STATSIG__2;
  }
});

// netlify/functions/drdsh/drdsh.mts
var import_js_on_device_eval_client = __toESM(require_src(), 1);
var config = '{"dynamic_configs":[],"feature_gates":[],"layers":{},"layer_configs":[],"has_updates":true,"time":1754608437048,"company_id":"1uYITXXXQ194aXOL4EqtF7","response_format":"dcs-v1","session_replay_info":{"sampling_rate":1,"recording_blocked":false},"id_lists":{},"diagnostics":{"initialize":10000,"dcs":1000,"download_config_specs":1000,"idlist":100,"get_id_list":100,"get_id_list_sources":100,"log":100,"log_event":100,"api_call":100},"sdk_flags":{},"sdk_configs":{"event_queue_size":2000,"event_content_encoding":"gzip","sampling_mode":"none"}}';
var drdsh_default = async (request, context) => {
  try {
    const requestID = crypto.randomUUID();
    const user = { customIDs: { requestID } };
    const start = performance.now();
    const client = new import_js_on_device_eval_client.StatsigOnDeviceEvalClient(
      "client-UJkQ3iTA4F89BoFfihUgroEvfdntf5yeb7mlUzego3c",
      {
        loggingEnabled: "always"
      }
    );
    client.dataAdapter.setData(config);
    client.initializeSync({
      disableBackgroundCacheRefresh: true
    });
    client.logEvent("drdsh_redirect", user);
    await client.flush();
    return new Response(null, {
      status: 301,
      headers: {
        Location: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
      }
    });
  } catch (error) {
    return new Response(error.toString(), {
      status: 301,
      headers: {
        Location: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
      }
    });
  }
};
export {
  drdsh_default as default
};
